// «WAV для CD» (страница «Запись CD» → «В файлы WAV»), главный процесс: выбор файлов, папок и места сохранения,
// запись готового звука на диск и проверка каждого файла.
//
// Звук в формат CD переводит окно (src/services/cdburn.js — тот же путь, что и при записи диска) и присылает
// сюда кусками 16-битный PCM. Здесь:
//   1) пишем во временный файл «.имя.wav.pulse-part» в выбранной папке (исходные файлы не трогаем никогда);
//   2) закрываем, открываем заново и проверяем: RIFF/WAVE, PCM целые со знаком, 16 бит, 44 100 Гц, 2 канала,
//      1411,2 кбит/с, размер данных совпадает с присланным, файл читается до конца;
//   3) только после проверки переименовываем в итоговое имя. Существующий файл заменяется, только если так
//      выбрал человек («Заменить»); иначе — «Пропустить» или имя с номером «… (2).wav».
// Остановка — временный файл удаляется. Брошенные временные файлы (выключили компьютер) удаляются при следующем
// сохранении в ту же папку.
'use strict';
const { dialog, shell, BrowserWindow } = require('electron');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');

const PART = '.pulse-part';
const RATE = 44100, CH = 2, BITS = 16, BYTERATE = RATE * CH * BITS / 8, ALIGN = CH * BITS / 8;   // 176 400 Б/с = 1411,2 кбит/с
let log = () => {};
const jobs = new Map();   // id → { fh, tmp, dst, dir, bytes }

function header(dataBytes) {
  const h = Buffer.alloc(44);
  h.write('RIFF', 0, 'latin1'); h.writeUInt32LE(36 + dataBytes, 4); h.write('WAVE', 8, 'latin1');
  h.write('fmt ', 12, 'latin1'); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(CH, 22);
  h.writeUInt32LE(RATE, 24); h.writeUInt32LE(BYTERATE, 28); h.writeUInt16LE(ALIGN, 32); h.writeUInt16LE(BITS, 34);
  h.write('data', 36, 'latin1'); h.writeUInt32LE(dataBytes, 40);
  return h;
}

// проверка готового файла: читаем заголовок по чанкам (как любой проигрыватель) и данные до конца
async function verify(file, expectBytes) {
  const fh = await fsp.open(file, 'r');
  try {
    const st = await fh.stat(); if (st.size < 44) return 'файл слишком короткий';
    const h = Buffer.alloc(Math.min(st.size, 4096)); await fh.read(h, 0, h.length, 0);
    if (h.toString('latin1', 0, 4) !== 'RIFF' || h.toString('latin1', 8, 12) !== 'WAVE') return 'нет заголовка RIFF/WAVE';
    if (h.readUInt32LE(4) !== st.size - 8) return 'размер в заголовке RIFF не совпадает с файлом';
    let o = 12, fmt = null, data = null;
    while (o + 8 <= h.length && !data) {
      const id = h.toString('latin1', o, o + 4), len = h.readUInt32LE(o + 4);
      if (id === 'fmt ') fmt = { tag: h.readUInt16LE(o + 8), ch: h.readUInt16LE(o + 10), sr: h.readUInt32LE(o + 12), br: h.readUInt32LE(o + 16), al: h.readUInt16LE(o + 20), bits: h.readUInt16LE(o + 22) };
      if (id === 'data') data = { off: o + 8, len };
      o += 8 + len + (len & 1);
    }
    if (!fmt) return 'нет описания формата (fmt)';
    if (fmt.tag !== 1) return 'звук не в PCM (код формата ' + fmt.tag + ')';
    if (fmt.bits !== BITS) return 'разрядность ' + fmt.bits + ' бит вместо 16';
    if (fmt.sr !== RATE) return 'частота ' + fmt.sr + ' Гц вместо 44 100';
    if (fmt.ch !== CH) return 'каналов: ' + fmt.ch + ' вместо 2';
    if (fmt.br !== BYTERATE || fmt.al !== ALIGN) return 'неверный поток данных в заголовке';
    if (!data) return 'нет блока со звуком (data)';
    if (data.len !== expectBytes) return 'записано ' + data.len + ' байт звука вместо ' + expectBytes;
    if (data.off + data.len !== st.size) return 'размер блока со звуком не совпадает с файлом';
    if (!data.len) return 'в файле нет звука';
    if (data.len % ALIGN) return 'данные обрываются посреди отсчёта';
    // читаем все данные — файл действительно читается с диска
    const b = Buffer.allocUnsafe(1 << 20); let pos = data.off;
    while (pos < st.size) { const { bytesRead } = await fh.read(b, 0, Math.min(b.length, st.size - pos), pos); if (!bytesRead) return 'файл не читается до конца'; pos += bytesRead; }
    return '';
  } finally { await fh.close().catch(() => {}); }
}

// имя без запрещённых в Windows и macOS символов
function safeName(s) {
  let n = String(s || '').normalize('NFC').replace(/[\\/:*?"<>|\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ').trim().replace(/[. ]+$/, '');
  if (!n) n = 'Трек'; if (/^(con|prn|aux|nul|com\d|lpt\d)$/i.test(n)) n = '_' + n;
  return n.slice(0, 150);
}
const exists = (p) => fsp.access(p).then(() => true, () => false);
async function freeName(dir, base) { for (let k = 2; k < 1000; k++) { const p = path.join(dir, base + ' (' + k + ').wav'); if (!(await exists(p))) return p; } throw new Error('слишком много файлов с таким именем'); }

async function cleanParts(dir) {
  try { for (const n of await fsp.readdir(dir)) if (n.endsWith(PART) && n.startsWith('.')) { const p = path.join(dir, n); const st = await fsp.stat(p).catch(() => null); if (st && Date.now() - st.mtimeMs > 6 * 3600e3) await fsp.rm(p, { force: true }); } } catch {}
}

// начать файл. mode: 'number' (имя с номером), 'skip', 'replace'
async function open(dir, name, mode) {
  if (typeof dir !== 'string' || !path.isAbsolute(dir)) return { ok: false, err: 'не выбрана папка для сохранения' };
  try { const st = await fsp.stat(dir); if (!st.isDirectory()) return { ok: false, err: 'папка для сохранения не найдена' }; } catch { return { ok: false, err: 'папка для сохранения не найдена' }; }
  const base = safeName(name); let dst = path.join(dir, base + '.wav');
  if (await exists(dst)) { if (mode === 'skip') return { ok: true, skip: true, path: dst }; if (mode !== 'replace') dst = await freeName(dir, base); }
  const tmp = path.join(dir, '.' + base + '.' + crypto.randomBytes(3).toString('hex') + PART);
  let fh; try { fh = await fsp.open(tmp, 'wx'); await fh.write(header(0), 0, 44, 0); }
  catch (e) { if (fh) await fh.close().catch(() => {}); await fsp.rm(tmp, { force: true }).catch(() => {}); return { ok: false, err: e && e.code === 'EACCES' || e && e.code === 'EPERM' ? 'нет прав на запись в эту папку' : e && e.code === 'ENOSPC' ? 'на диске не хватает места' : 'не удалось создать файл: ' + ((e && e.message) || e) }; }
  const id = crypto.randomUUID(); jobs.set(id, { fh, tmp, dst, dir, bytes: 0, mode });
  return { ok: true, id, path: dst };
}
async function write(id, data) {
  const j = jobs.get(id); if (!j) return { ok: false, err: 'файл уже закрыт' };
  try { const b = Buffer.from(data); if (b.length % ALIGN) throw new Error('кусок звука неполный'); await j.fh.write(b, 0, b.length, 44 + j.bytes); j.bytes += b.length; return { ok: true }; }
  catch (e) { await abort(id); return { ok: false, err: e && e.code === 'ENOSPC' ? 'на диске не хватает места' : 'ошибка записи: ' + ((e && e.message) || e) }; }
}
async function finish(id, expectBytes) {
  const j = jobs.get(id); if (!j) return { ok: false, err: 'файл уже закрыт' };
  try {
    await j.fh.write(header(j.bytes), 0, 44, 0); await j.fh.sync().catch(() => {}); await j.fh.close(); j.fh = null;
    const bad = await verify(j.tmp, expectBytes); if (bad) throw new Error('проверка не пройдена: ' + bad);
    // итоговое имя: «Заменить» — поверх; иначе — имя могло занять что-то другое, пока шла конвертация
    let dst = j.dst; if (j.mode !== 'replace' && (await exists(dst))) dst = await freeName(j.dir, path.basename(dst, '.wav'));
    await fsp.rename(j.tmp, dst); jobs.delete(id);
    return { ok: true, path: dst, bytes: j.bytes, sec: j.bytes / BYTERATE };
  } catch (e) { log('wav для cd:', e && e.message); await abort(id); return { ok: false, err: String((e && e.message) || e) }; }
}
async function abort(id) {
  const j = jobs.get(id); if (!j) return true; jobs.delete(id);
  if (j.fh) await j.fh.close().catch(() => {}); await fsp.rm(j.tmp, { force: true }).catch(() => {});
  return true;
}

function setup(o) {
  log = (o && o.log) || log; const sec = o.sec; const local = require('./local');
  const win = (e) => BrowserWindow.fromWebContents(e.sender);
  const AUD = ['flac', 'mp3', 'm4a', 'aac', 'ogg', 'oga', 'opus', 'wav', 'ape', 'wv', 'aiff', 'aif', 'aifc', 'wma', 'webm'];
  sec.handle('cdw:pickFiles', async (e) => {
    const r = await dialog.showOpenDialog(win(e), { title: 'Аудиофайлы', properties: ['openFile', 'multiSelections'], filters: [{ name: 'Аудио', extensions: AUD }, { name: 'Все файлы', extensions: ['*'] }] });
    return r.canceled ? null : local.adhoc(r.filePaths);
  });
  sec.handle('cdw:pickFolder', async (e) => {
    const r = await dialog.showOpenDialog(win(e), { title: 'Папка с музыкой', properties: ['openDirectory'] });
    if (r.canceled || !r.filePaths[0]) return null;
    const list = await local.folderAudio(r.filePaths[0]); const out = await local.adhoc(list);
    return { ...out, folder: r.filePaths[0] };
  });
  sec.handle('cdw:addPaths', (_e, paths) => local.adhoc((Array.isArray(paths) ? paths : []).filter((p) => typeof p === 'string')));
  sec.handle('cdw:pickOut', async (e, cur) => {
    const r = await dialog.showOpenDialog(win(e), { title: 'Куда сохранить WAV', defaultPath: typeof cur === 'string' && cur ? cur : undefined, properties: ['openDirectory', 'createDirectory'] });
    if (r.canceled || !r.filePaths[0]) return null; cleanParts(r.filePaths[0]); return r.filePaths[0];
  });
  sec.handle('cdw:open', (_e, dir, name, mode) => open(dir, name, mode));
  sec.handle('cdw:write', (_e, id, data) => write(id, data));
  sec.handle('cdw:finish', (_e, id, n) => finish(id, n | 0));
  sec.handle('cdw:abort', (_e, id) => abort(id));
  sec.handle('cdw:reveal', (_e, p) => { if (typeof p !== 'string' || !path.isAbsolute(p)) return false; if (/\.wav$/i.test(p)) shell.showItemInFolder(p); else shell.openPath(p); return true; });
  require('electron').app.on('will-quit', () => { for (const id of [...jobs.keys()]) { const j = jobs.get(id); try { if (j.fh) fs.closeSync(j.fh.fd); } catch {} try { fs.rmSync(j.tmp, { force: true }); } catch {} } });
}
module.exports = { setup, verify, header, safeName, open, write, finish, abort };
