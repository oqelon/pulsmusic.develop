// WavPack (.wv) — свой декодер на чистом JS, без сторонних модулей.
// Поддерживается: версии 4.02–4.10 (и блоки WavPack 5 с PCM), без потерь и гибридный режим (только .wv, без .wvc),
// моно/стерео/многоканальный звук, 8–32 бит, 32-бит float, «лишние» биты (ID_WVX_BITSTREAM). DSD — нет.
// Устроено по описанию формата и декодеру libavcodec/wavpack.c; проверено побитно против ffmpeg.
'use strict';

const RATES = [6000, 8000, 9600, 11025, 12000, 16000, 22050, 24000, 32000, 44100, 48000, 64000, 88200, 96000, 192000];
const F = { MONO: 0x4, HYBRID: 0x8, JOINT: 0x10, CROSS: 0x20, SHAPE: 0x40, FLOAT: 0x80, INT32: 0x100, HBITRATE: 0x200, HBALANCE: 0x400,
  INITIAL: 0x800, FINAL: 0x1000, FALSE_STEREO: 0x40000000, DSD: 0x80000000 };

// таблицы 2^x и log2 из WavPack: 256 значений дробной части
const EXP2 = new Uint8Array(256), LOG2 = new Uint8Array(256);
for (let i = 0; i < 256; i++) { EXP2[i] = (Math.round(Math.pow(2, i / 256) * 256) - 256) & 255; LOG2[i] = Math.round(Math.log2(1 + i / 256) * 256) & 255; }
function wpExp2(v) {
  v = (v << 16) >> 16; let neg = false; if (v < 0) { v = -v; neg = true; }
  let res = EXP2[v & 255] | 0x100; v >>= 8; if (v > 31) return -2147483648;
  res = v > 9 ? res << (v - 9) : res >> (9 - v);
  return neg ? -res : res;
}
function wpLog2(val) {
  val = val >>> 0; if (!val) return 0; val += val >>> 9; const bits = 31 - Math.clz32(val);
  if (bits < 9) return (bits << 8) + LOG2[(val << (9 - bits)) & 255];
  return (bits << 8) + LOG2[(val >>> (bits - 9)) & 255];
}

// чтение битов младшим разрядом вперёд
class Bits {
  constructor(d, off, len) { this.d = d; this.p = off; this.end = off + len; this.c = 0; this.n = 0; this.used = 0; this.total = len * 8; }
  left() { return this.total - this.used; }
  fill() { while (this.n <= 24) { this.c = (this.c | ((this.p < this.end ? this.d[this.p] : 0) << this.n)) >>> 0; this.p++; this.n += 8; } }
  bit() { if (!this.n) this.fill(); const b = this.c & 1; this.c >>>= 1; this.n--; this.used++; return b; }
  get(k) { // k ≤ 32
    if (!k) return 0;
    if (k > 24) { const lo = this.get(16); return (lo + this.get(k - 16) * 65536) >>> 0; }
    if (this.n < k) this.fill();
    const v = this.c & ((1 << k) - 1); this.c >>>= k; this.n -= k; this.used += k; return v >>> 0;
  }
  unary33() { let k = 0; while (k < 33 && this.bit()) k++; return k; }
}

const LEVEL_DECAY = (a) => (a + 0x80) >> 8;

function getTail(gb, k) {
  if (k < 1) return 0;
  const p = 31 - Math.clz32(k); const e = 2 ** (p + 1) - k - 1;
  let res = gb.get(p);
  if (res >= e) res = res * 2 - e + gb.bit();
  return res;
}

// значение из энтропийного кода (wv_get_value в libavcodec)
function getValue(s, gb, ch) {
  const c = s.ch[ch]; s.last = false;
  if (s.ch[0].median[0] < 2 && s.ch[1].median[0] < 2 && !s.zero && !s.one) {
    if (s.zeroes) {
      s.zeroes--;
      if (s.zeroes) { c.slow -= LEVEL_DECAY(c.slow); return 0; }
    } else {
      let t = gb.unary33();
      if (t >= 2) { if (t >= 32 || gb.left() < t - 1) { s.last = true; return 0; } t = gb.get(t - 1) + 2 ** (t - 1); }
      s.zeroes = t;
      if (s.zeroes) { s.ch[0].median.fill(0); s.ch[1].median.fill(0); c.slow -= LEVEL_DECAY(c.slow); return 0; }
    }
  }
  let t;
  if (s.zero) { t = 0; s.zero = 0; }
  else {
    t = gb.unary33(); if (gb.left() < 0) { s.last = true; return 0; }
    if (t === 16) {
      const t2 = gb.unary33();
      if (t2 < 2) t += t2;
      else { if (t2 >= 32 || gb.left() < t2 - 1) { s.last = true; return 0; } t += gb.get(t2 - 1) + 2 ** (t2 - 1); }
    }
    if (s.one) { s.one = t & 1; t = (t >> 1) + 1; } else { s.one = t & 1; t >>= 1; }
    s.zero = s.one ? 0 : 1;
  }
  if (s.hybrid && !ch) updateErrorLimit(s);
  const m = c.median; const G = (n) => (m[n] >>> 4) + 1;
  const DEC = (n) => { m[n] = (m[n] - Math.floor((m[n] + (128 >> n) - 2) / (128 >> n)) * 2) >>> 0; };
  const INC = (n) => { m[n] = (m[n] + Math.floor((m[n] + (128 >> n)) / (128 >> n)) * 5) >>> 0; };
  let base, add;
  if (!t) { base = 0; add = G(0) - 1; DEC(0); }
  else if (t === 1) { base = G(0); add = G(1) - 1; INC(0); DEC(1); }
  else if (t === 2) { base = G(0) + G(1); add = G(2) - 1; INC(0); INC(1); DEC(2); }
  else { base = G(0) + G(1) + G(2) * (t - 2); add = G(2) - 1; INC(0); INC(1); INC(2); }
  base >>>= 0; let ret;
  if (!c.errLimit) {
    if (add >= 0x2000000) { s.last = true; return 0; }
    ret = base + getTail(gb, add);
    if (gb.left() <= 0) { s.last = true; return 0; }
  } else {
    let mid = Math.floor((base * 2 + add + 1) / 2);
    while (add > c.errLimit) {
      if (gb.left() <= 0) { s.last = true; return 0; }
      if (gb.bit()) { add -= mid - base; base = mid; } else add = mid - base - 1;
      mid = Math.floor((base * 2 + add + 1) / 2);
    }
    ret = mid;
  }
  ret >>>= 0;
  const sign = gb.bit();
  if (s.hbitrate) c.slow += wpLog2(ret) - LEVEL_DECAY(c.slow);
  return sign ? ~ret : ret | 0;
}
function updateErrorLimit(s) {
  const br = [0, 0], sl = [0, 0], st = s.stereo ? 1 : 0;
  for (let i = 0; i <= st; i++) { const c = s.ch[i]; c.bitrateAcc = (c.bitrateAcc + c.bitrateDelta) >>> 0; br[i] = c.bitrateAcc >>> 16; sl[i] = LEVEL_DECAY(c.slow); }
  if (st && s.hbitrate) {
    const balance = (sl[1] - sl[0] + br[1] + 1) >> 1;
    if (balance > br[0]) { br[1] = br[0] * 2; br[0] = 0; }
    else if (-balance > br[0]) { br[0] *= 2; br[1] = 0; }
    else { br[1] = br[0] + balance; br[0] = br[0] - balance; }
  }
  for (let i = 0; i <= st; i++) {
    if (s.hbitrate) s.ch[i].errLimit = sl[i] - br[i] > -0x100 ? wpExp2(sl[i] - br[i] + 0x100) >>> 0 : 0;
    else s.ch[i].errLimit = wpExp2(br[i]) >>> 0;
  }
}

// итоговое целое значение (wv_get_value_integer)
function toInt(s, S) {
  if (s.extraBits) {
    S = S * (1 << s.extraBits);
    if (s.gx && s.gx.left() >= s.extraBits) S = (S | s.gx.get(s.extraBits)) | 0;
  }
  let bit = (S & s.and) | s.or;
  bit = (((S + bit) << s.shift) - bit) | 0;
  if (s.hybrid) bit = Math.min(s.maxclip, Math.max(s.minclip, bit));
  return (bit << s.postShift) | 0;
}
const f32 = new Float32Array(1), u32 = new Uint32Array(f32.buffer);
function toFloat(s, S) {
  let exp = s.fmaxExp, sign = 0; const gx = s.gx;
  if (S) {
    S = S * 2 ** s.fshift; sign = S < 0 ? 1 : 0; if (sign) S = -S;
    if (S >= 0x1000000) { S = gx && gx.bit() ? gx.get(23) : 0; exp = 255; }
    else if (exp) {
      let shift = 23 - (31 - Math.clz32(S)); exp = s.fmaxExp;
      if (exp <= shift) shift = --exp;
      exp -= shift;
      if (shift) {
        S = S * 2 ** shift;
        if ((s.fflag & 1) || (gx && (s.fflag & 2) && gx.bit())) S += (1 << shift) - 1;
        else if (gx && (s.fflag & 4)) S += gx.get(shift);
      }
    } else exp = s.fmaxExp;
    S = S & 0x7fffff;
  } else {
    exp = 0;
    if (gx && (s.fflag & 8)) {
      if (gx.bit()) { S = gx.get(23); if (s.fmaxExp >= 25) exp = gx.get(8); sign = gx.bit(); }
      else if (s.fflag & 0x10) sign = gx.bit();
    }
  }
  u32[0] = ((sign << 31) | (exp << 23) | S) >>> 0; return f32[0];
}

const w10 = (w, a) => Math.floor((w * a + 512) / 1024);

function unpackStereo(s, gb, outL, outR, n) {
  const D = s.decorr; let pos = 0, count = 0;
  s.one = s.zero = s.zeroes = 0;
  while (count < n) {
    let L = getValue(s, gb, 0); if (s.last) break;
    let R = getValue(s, gb, 1); if (s.last) break;
    for (let i = 0; i < D.length; i++) {
      const d = D[i], t = d.value; let A, B, L2, R2, j;
      if (t > 0) {
        if (t > 8) {
          if (t & 1) { A = (2 * d.sA[0] - d.sA[1]) | 0; B = (2 * d.sB[0] - d.sB[1]) | 0; }
          else { A = ((3 * d.sA[0] - d.sA[1]) | 0) >> 1; B = ((3 * d.sB[0] - d.sB[1]) | 0) >> 1; }
          d.sA[1] = d.sA[0]; d.sB[1] = d.sB[0]; j = 0;
        } else { A = d.sA[pos]; B = d.sB[pos]; j = (pos + t) & 7; }
        L2 = (L + w10(d.wA, A)) | 0; R2 = (R + w10(d.wB, B)) | 0;
        if (A && L) d.wA -= ((((L ^ A) >> 30) & 2) - 1) * d.delta;
        if (B && R) d.wB -= ((((R ^ B) >> 30) & 2) - 1) * d.delta;
        d.sA[j] = L = L2; d.sB[j] = R = R2;
      } else if (t === -1) {
        L2 = (L + w10(d.wA, d.sA[0])) | 0; d.wA = clipW(d.wA, d.delta, d.sA[0], L); L = L2;
        R2 = (R + w10(d.wB, L2)) | 0; d.wB = clipW(d.wB, d.delta, L2, R); R = R2; d.sA[0] = R;
      } else {
        R2 = (R + w10(d.wB, d.sB[0])) | 0; d.wB = clipW(d.wB, d.delta, d.sB[0], R); R = R2;
        if (t === -3) { R2 = d.sA[0]; d.sA[0] = R; }
        L2 = (L + w10(d.wA, R2)) | 0; d.wA = clipW(d.wA, d.delta, R2, L); L = L2; d.sB[0] = L;
      }
    }
    pos = (pos + 1) & 7;
    if (s.joint) { R = (R - (L >> 1)) | 0; L = (L + R) | 0; }
    if (s.float) { outL[count] = toFloat(s, L); outR[count] = toFloat(s, R); }
    else { outL[count] = toInt(s, L); outR[count] = toInt(s, R); }
    count++;
  }
  return count;
}
function clipW(w, delta, smp, inp) {
  if (smp && inp) { if ((smp ^ inp) < 0) { w -= delta; if (w < -1024) w = -1024; } else { w += delta; if (w > 1024) w = 1024; } }
  return w;
}
function unpackMono(s, gb, out, n) {
  const D = s.decorr; let pos = 0, count = 0;
  s.one = s.zero = s.zeroes = 0;
  while (count < n) {
    let T = getValue(s, gb, 0); if (s.last) break;
    let S = T;
    for (let i = 0; i < D.length; i++) {
      const d = D[i], t = d.value; let A, j;
      if (t > 8) {
        A = t & 1 ? (2 * d.sA[0] - d.sA[1]) | 0 : ((3 * d.sA[0] - d.sA[1]) | 0) >> 1;
        d.sA[1] = d.sA[0]; j = 0;
      } else { A = d.sA[pos]; j = (pos + t) & 7; }
      S = (T + w10(d.wA, A)) | 0;
      if (A && T) d.wA -= ((((T ^ A) >> 30) & 2) - 1) * d.delta;
      d.sA[j] = T = S;
    }
    pos = (pos + 1) & 7;
    out[count++] = s.float ? toFloat(s, S) : toInt(s, S);
  }
  return count;
}

// метаданные блока: [id, данные]
function* subBlocks(b, off, end) {
  while (off + 2 <= end) {
    const id = b[off]; let size = b[off + 1] * 2, h = 2;
    if (id & 0x80) { if (off + 4 > end) return; size = (b[off + 1] | (b[off + 2] << 8) | (b[off + 3] << 16)) * 2; h = 4; }
    const real = id & 0x40 ? size - 1 : size;
    if (off + h + real > end) return;
    yield [id & 0x3f, id & 0x20, off + h, real];
    off += h + size;
  }
}

// один блок (1 или 2 канала) → массивы каналов
function decodeBlock(b, off, outCh) {
  const flags = b.readUInt32LE(off + 24) >>> 0, n = b.readUInt32LE(off + 20), end = off + 8 + b.readUInt32LE(off + 4);
  if (flags & F.DSD) throw new Error('WavPack DSD не поддерживается');
  const bytes = (flags & 3) + 1, mono = !!(flags & F.MONO), falseSt = !!(flags & F.FALSE_STEREO);
  const s = { decorr: [], ch: [mk(), mk()], extraBits: 0, and: 0, or: 0, shift: 0, gx: null, hybrid: !!(flags & F.HYBRID), hbitrate: !!(flags & F.HBITRATE), hbalance: !!(flags & F.HBALANCE),
    joint: !!(flags & F.JOINT), float: !!(flags & F.FLOAT), stereo: !mono, postShift: (flags >> 13) & 0x1f, maxclip: 2 ** (bytes * 8 - 1) - 1, minclip: -(2 ** (bytes * 8 - 1)),
    fflag: 0, fshift: 0, fmaxExp: 0, zero: 0, one: 0, zeroes: 0, last: false };
  let gb = null;
  for (const [id, , p, len] of subBlocks(b, off + 32, end)) {
    if (id === 2) { // термы
      s.decorr = []; for (let i = 0; i < len; i++) { const v = b[p + i]; s.decorr.unshift({ value: (v & 0x1f) - 5, delta: v >> 5, wA: 0, wB: 0, sA: new Int32Array(8), sB: new Int32Array(8) }); }
    } else if (id === 3) { // веса
      const per = mono ? 1 : 2, cnt = Math.min(Math.floor(len / per), s.decorr.length);
      for (let i = 0, q = p; i < cnt; i++) { const d = s.decorr[s.decorr.length - 1 - i];
        let w = ((b[q++] << 24) >> 24) * 8; if (w > 0) w += (w + 64) >> 7; d.wA = w;
        if (!mono) { w = ((b[q++] << 24) >> 24) * 8; if (w > 0) w += (w + 64) >> 7; d.wB = w; } }
    } else if (id === 4) { // начальные отсчёты
      let q = p, t = 0; const rd = () => { const v = wpExp2(b.readInt16LE(q)); q += 2; return v; };
      for (let i = s.decorr.length - 1; i >= 0 && t < len; i--) { const d = s.decorr[i];
        if (d.value > 8) { d.sA[0] = rd(); d.sA[1] = rd(); if (!mono) { d.sB[0] = rd(); d.sB[1] = rd(); t += 4; } t += 4; }
        else if (d.value < 0) { d.sA[0] = rd(); d.sB[0] = rd(); t += 4; }
        else { for (let j = 0; j < d.value; j++) { d.sA[j] = rd(); if (!mono) d.sB[j] = rd(); } t += d.value * 2 * (mono ? 1 : 2); } }
    } else if (id === 5) { // энтропия
      for (let i = 0, q = p; i < (mono ? 1 : 2); i++) for (let j = 0; j < 3; j++) { s.ch[i].median[j] = wpExp2(b.readInt16LE(q)) >>> 0; q += 2; }
    } else if (id === 6) { // гибрид
      let q = p;
      if (s.hbitrate) { for (let i = 0; i < (mono ? 1 : 2); i++) { s.ch[i].slow = wpExp2(b.readInt16LE(q)); q += 2; } }
      for (let i = 0; i < (mono ? 1 : 2); i++) { s.ch[i].bitrateAcc = b.readUInt16LE(q) * 65536; q += 2; }
      if (q < p + len) { for (let i = 0; i < (mono ? 1 : 2); i++) { s.ch[i].bitrateDelta = wpExp2(b.readInt16LE(q)); q += 2; } }
      else for (let i = 0; i < (mono ? 1 : 2); i++) s.ch[i].bitrateDelta = 0;
    } else if (id === 8) { s.fflag = b[p]; s.fshift = b[p + 1]; s.fmaxExp = b[p + 2]; }
    else if (id === 9) { // int32
      const v = [b[p], b[p + 1], b[p + 2], b[p + 3]];
      if (v[0]) s.extraBits = v[0]; else if (v[1]) s.shift = v[1]; else if (v[2]) { s.and = s.or = 1; s.shift = v[2]; } else if (v[3]) { s.and = 1; s.shift = v[3]; }
      if (s.hybrid && bytes === 4 && s.postShift < 8 && s.shift > 8) { s.postShift += 8; s.shift -= 8; s.maxclip = Math.floor(s.maxclip / 256); s.minclip = Math.floor(s.minclip / 256); }
    } else if (id === 10) gb = new Bits(b, p, len);
    else if (id === 12 && len > 4) { s.gx = new Bits(b, p + 4, len - 4); }
  }
  if (!s.extraBits && !s.float) s.gx = null;
  if (!gb) throw new Error('WavPack: в блоке нет звука');
  const A = s.float ? new Float32Array(n) : new Int32Array(n);
  if (mono) {
    const got = unpackMono(s, gb, A, n);
    outCh.push(A); if (falseSt) outCh.push(A.slice());
    return got;
  }
  const B = s.float ? new Float32Array(n) : new Int32Array(n);
  const got = unpackStereo(s, gb, A, B, n); outCh.push(A, B); return got;
}
function mk() { return { median: new Uint32Array(3), slow: 0, errLimit: 0, bitrateAcc: 0, bitrateDelta: 0 }; }

// ---------- файл ----------
// Разбор заголовков блоков: таблица кадров (кадр = все блоки одного отрезка, для многоканального звука их несколько)
function readHead(b, o) {
  if (b.toString('latin1', o, o + 4) !== 'wvpk') return null;
  const size = b.readUInt32LE(o + 4) + 8, ver = b.readUInt16LE(o + 8);
  let index = b.readUInt32LE(o + 16), total = b.readUInt32LE(o + 12);
  if (ver >= 0x410) { index += b[o + 10] * 2 ** 32; if (total !== 0xffffffff) total += b[o + 11] * 2 ** 32; }
  return { size, ver, total, index, n: b.readUInt32LE(o + 20), flags: b.readUInt32LE(o + 24) >>> 0 };
}
function info(fs, fd, fileSize) {
  const frames = []; let pos = 0, first = null, cur = null; const H = Buffer.alloc(32); let misses = 0;
  // пропускаем ID3 в начале, если есть
  fs.readSync(fd, H, 0, 10, 0); if (H.toString('latin1', 0, 3) === 'ID3') pos = 10 + ((H[6] & 127) << 21 | (H[7] & 127) << 14 | (H[8] & 127) << 7 | (H[9] & 127));
  while (pos + 32 <= fileSize) {
    fs.readSync(fd, H, 0, 32, pos); const h = readHead(H, 0);
    if (!h || h.size < 32 || h.ver < 0x402 || h.ver > 0x410) {
      if (++misses > 1 && frames.length) break;   // дальше — теги
      const W = Buffer.alloc(Math.min(1 << 20, fileSize - pos)); fs.readSync(fd, W, 0, W.length, pos);
      const k = W.indexOf('wvpk', 1, 'latin1'); if (k < 0) break; pos += k; continue;
    }
    misses = 0;
    if (h.n) {
      if (!first) {
        first = h; first.channels = 0; first.rate = RATES[(h.flags >> 23) & 15] || 0; first.chMask = 0;
        // каналы и нестандартная частота — в метаданных первого блока
        const B = Buffer.alloc(Math.min(h.size, 1 << 20)); fs.readSync(fd, B, 0, B.length, pos);
        for (const [id, , p, len] of subBlocks(B, 32, B.length)) {
          if (id === 0xd && len) { first.channels = B[p]; if (len >= 2) first.chMask = len === 2 ? B[p + 1] : B.readUIntLE(p + 1, Math.min(4, len - 1)); }
          if (id === 0x27 && len >= 3) first.rate = B.readUIntLE(p, Math.min(4, len) === 4 ? 4 : 3);
        }
        if (!first.channels) first.channels = h.flags & F.MONO && !(h.flags & F.FALSE_STEREO) ? 1 : 2;
      }
      if (h.flags & F.INITIAL || !cur) { cur = { off: pos, len: 0, start: h.index, n: h.n }; frames.push(cur); }
      cur.len = pos + h.size - cur.off;
    }
    pos += h.size;
  }
  if (!first) throw new Error('Это не файл WavPack');
  if (first.flags & F.DSD) throw new Error('WavPack DSD не поддерживается');
  const base = frames.length ? frames[0].start : 0; for (const f of frames) f.start -= base;
  const last = frames[frames.length - 1]; const total = last ? last.start + last.n : 0;
  const bits = first.flags & F.FLOAT ? 32 : ((first.flags & 3) + 1) * 8;
  return { codec: 'WavPack', rate: first.rate, channels: first.channels, bits, float: !!(first.flags & F.FLOAT), total, frames,
    lossy: !!(first.flags & F.HYBRID), dataEnd: last ? last.off + last.len : pos };
}
// кадр → каналы
function decodeFrame(buf) {
  const ch = []; let o = 0, n = 0;
  while (o + 32 <= buf.length) { const h = readHead(buf, o); if (!h) break; if (h.n) { n = h.n; decodeBlock(buf, o, ch); } o += h.size; }
  return { ch, n };
}
module.exports = { info, decodeFrame, wpExp2 };
