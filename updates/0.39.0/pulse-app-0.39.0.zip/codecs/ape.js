// Monkey's Audio (.ape) — свой декодер на чистом JS, без сторонних модулей.
// Поддерживаются файлы версий 3.95 и новее (все рипы примерно с 2002 года): 8/16/24 бит, моно и стерео,
// все уровни сжатия — Fast, Normal, High, Extra High, Insane. Каждый кадр декодируется независимо,
// поэтому перемотка мгновенная. Устроено по описанию формата и декодеру libavcodec/apedec.c.
'use strict';

const HISTORY = 512, PRED = 50;
const YDELAYA = 50, YDELAYB = 42, XDELAYA = 34, XDELAYB = 26, YADAPTA = 18, XADAPTA = 14, YADAPTB = 10, XADAPTB = 5;
const ORDERS = [[], [16], [64], [32, 256], [16, 256, 1280]];
const FRAC = [[], [11], [11], [10, 13], [11, 13, 15]];
const COUNTS_3970 = [0, 14824, 28224, 39348, 47855, 53994, 58171, 60926, 62682, 63786, 64463, 64878, 65126, 65276, 65365, 65419, 65450, 65469, 65480, 65487, 65491, 65493];
const COUNTS_3980 = [0, 19578, 36160, 48417, 56323, 60899, 63265, 64435, 64971, 65232, 65351, 65416, 65447, 65466, 65476, 65482, 65485, 65488, 65490, 65491, 65492, 65493];
const DIFF = (c) => c.slice(1).map((v, i) => v - c[i]);
const DIFF_3970 = DIFF(COUNTS_3970), DIFF_3980 = DIFF(COUNTS_3980);
const BOTTOM = 0x800000;   // (1 << 31) >> 8
const sign = (x) => (x < 0 ? 1 : 0) - (x > 0 ? 1 : 0);   // «обратный знак», как APESIGN

// ---------- кадр ----------
class Frame {
  constructor(d, ptr, ver) { this.d = d; this.p = ptr; this.end = d.length; this.ver = ver; this.err = false; }
  be32() { const d = this.d, p = this.p; this.p += 4; return ((d[p] << 24) | (d[p + 1] << 16) | (d[p + 2] << 8) | d[p + 3]) >>> 0; }
  byte() { if (this.p < this.end) return this.d[this.p++]; this.err = true; this.p++; return 0; }
  start() { this.buffer = this.byte(); this.low = this.buffer >>> 1; this.range = 128; }
  norm() {
    while (this.range <= BOTTOM) {
      this.buffer = ((this.buffer << 8) | this.byte()) >>> 0;
      this.low = ((this.low * 256) % 4294967296 + ((this.buffer >>> 1) & 0xff)) >>> 0;
      this.range = (this.range * 256) >>> 0;
    }
  }
  culfreq(tot) { this.norm(); this.help = Math.floor(this.range / tot); return Math.floor(this.low / this.help); }
  culshift(sh) { this.norm(); this.help = this.range >>> sh; return Math.floor(this.low / this.help); }
  update(sy, lt) { this.low = (this.low - this.help * lt) >>> 0; this.range = (this.help * sy) >>> 0; }
  bits(n) { const s = this.culshift(n); this.update(1, s); return s; }
  symbol(counts, diff) {
    const cf = this.culshift(16);
    if (cf > 65492) { this.update(1, cf); if (cf > 65535) this.err = true; return cf - 65535 + 63; }
    let s = 0; while (counts[s + 1] <= cf) s++;
    this.update(diff[s], counts[s]); return s;
  }
}
function updateRice(r, x) {
  const lim = r.k ? 2 ** (r.k + 4) : 0;
  r.ksum = r.ksum + Math.floor((x + 1) / 2) - ((r.ksum + 16) >>> 5);
  if (r.ksum < lim) r.k--;
  else if (r.ksum >= 2 ** (r.k + 5) && r.k < 24) r.k++;
}
const toSigned = (x) => (x & 1 ? Math.floor(x / 2) + 1 : -Math.floor(x / 2));
function value3990(f, r) {
  let pivot = r.ksum >>> 5; if (!pivot) pivot = 1;
  let overflow = f.symbol(COUNTS_3980, DIFF_3980);
  if (overflow === 63) { overflow = f.bits(16) * 65536; overflow += f.bits(16); }
  let base;
  if (pivot < 0x10000) { base = f.culfreq(pivot); f.update(1, base); }
  else {
    let hi = pivot, bb = 0; while (hi >= 0x10000) { hi = Math.floor(hi / 2); bb++; }
    hi = f.culfreq(hi + 1); f.update(1, hi);
    const lo = f.culfreq(2 ** bb); f.update(1, lo);
    base = hi * 2 ** bb + lo;
  }
  const x = (base + overflow * pivot) % 4294967296;
  updateRice(r, x); return toSigned(x) | 0;
}
function value3900(f, r, ver) {
  let overflow = f.symbol(COUNTS_3970, DIFF_3970), k;
  if (overflow === 63) { k = f.bits(5); overflow = 0; } else k = r.k < 1 ? 0 : r.k - 1;
  let x;
  if (k <= 16 || ver < 3910) { if (k > 23) { f.err = true; return 0; } x = f.bits(k); }
  else if (k <= 31) { x = f.bits(16); if (k > 16) x += f.bits(k - 16) * 65536; }
  else { f.err = true; return 0; }
  x = (x + overflow * 2 ** k) % 4294967296;
  updateRice(r, x); return toSigned(x) | 0;
}

// ---------- адаптивные фильтры (NN-фильтры Monkey's Audio) ----------
// Самое тяжёлое место (уровень Insane — 1552 умножения на отсчёт и канал), поэтому скалярное произведение и
// подстройка коэффициентов идут через крошечный модуль WebAssembly SIMD (i32x4.dot_i16x8_s, i16x8.add/sub —
// та же целочисленная арифметика с переполнением, что и в эталоне). Нет SIMD — те же циклы на JS.
const WASM = 'AGFzbQEAAAABDgJgA39/fwF/YAN/f38AAwQDAAEBBQMBAAQHFwQBbQIAA2RvdAAAA2FkZAABA3N1YgACCsABA1ICAX8Be0EA/REhBEEAIQMDQCAEIAAgA2r9AAAAIAEgA2r9AAAA/boB/a4BIQQgA0EQaiIDIAJJDQALIAT9GwAgBP0bAWogBP0bAmogBP0bA2oLNQEBf0EAIQMDQCAAIANqIAAgA2r9AAAAIAEgA2r9AAAA/Y4B/QsAACADQRBqIgMgAkkNAAsLNQEBf0EAIQMDQCAAIANqIAAgA2r9AAAAIAEgA2r9AAAA/ZEB/QsAACADQRBqIgMgAkkNAAsL';
let W = null;
try { W = new WebAssembly.Instance(new WebAssembly.Module(Buffer.from(WASM, 'base64'))).exports; } catch { W = null; }
let heap = 0;   // буферы фильтров лежат в памяти модуля; на каждый кадр раздаются заново
function mkFilter(order) {
  const n = order + HISTORY + order * 2;
  if (W) {
    const at = heap; heap += n * 2; heap = (heap + 15) & ~15;
    const all = new Int16Array(W.m.buffer, at, n); all.fill(0);
    return { order, coeffs: all.subarray(0, order), hist: all.subarray(order), cb: at, hb: at + order * 2, delay: order * 2, adapt: order, avg: 0 };
  }
  return { order, coeffs: new Int16Array(order), hist: new Int16Array(HISTORY + order * 2), delay: order * 2, adapt: order, avg: 0 };
}
function applyFilter(F, data, n, frac, ver) {
  const { order, coeffs, hist } = F; const half = 2 ** (frac - 1), div = 2 ** frac;
  for (let i = 0; i < n; i++) {
    const x = data[i]; let acc = 0;
    const dv = F.delay - order, av = F.adapt - order;
    if (W) {
      acc = W.dot(F.cb, F.hb + dv * 2, order * 2);
      if (x > 0) W.sub(F.cb, F.hb + av * 2, order * 2); else if (x < 0) W.add(F.cb, F.hb + av * 2, order * 2);
    } else {
      // сумма произведений: каждое меньше 2^30, сумма до 1280 штук точна в double — перенос в int32 один раз в конце
      for (let k = 0; k < order; k++) acc += coeffs[k] * hist[dv + k];
      acc |= 0;
      // коэффициенты подстраиваются по знаку входа (у Monkey's Audio знак «обратный»)
      if (x > 0) { for (let k = 0; k < order; k++) coeffs[k] -= hist[av + k]; }
      else if (x < 0) { for (let k = 0; k < order; k++) coeffs[k] += hist[av + k]; }
    }
    let res = Math.floor((acc + half) / div); res = (res + x) | 0; data[i] = res;
    hist[F.delay++] = res > 32767 ? 32767 : res < -32768 ? -32768 : res;
    const a = F.adapt;
    if (ver < 3980) {
      hist[a] = res === 0 ? 0 : ((res >> 28) & 8) - 4; hist[a - 4] >>= 1; hist[a - 8] >>= 1;
    } else {
      const abs = Math.abs(res);
      hist[a] = abs ? sign(res) * (8 << ((abs > F.avg * 3 ? 1 : 0) + (abs > F.avg + Math.floor(F.avg / 3) ? 1 : 0))) : 0;
      F.avg = (F.avg + Math.trunc((abs - F.avg) / 16)) >>> 0;
      hist[a - 1] >>= 1; hist[a - 2] >>= 1; hist[a - 8] >>= 1;
    }
    F.adapt++;
    if (F.delay === HISTORY + order * 2) { hist.copyWithin(0, F.delay - order * 2, F.delay); F.delay = order * 2; F.adapt = order; }
  }
}

// ---------- предсказатель (3.95+) ----------
function mkPred() {
  return { hist: new Int32Array(HISTORY + PRED), b: 0, lastA: [0, 0], filterA: [0, 0], filterB: [0, 0],
    coeffsA: [Int32Array.from([360, 317, -109, 98]), Int32Array.from([360, 317, -109, 98])], coeffsB: [new Int32Array(5), new Int32Array(5)] };
}
function predUpdate(p, decoded, f, dA, dB, aA, aB) {
  const h = p.hist, b = p.b, cA = p.coeffsA[f], cB = p.coeffsB[f];
  h[b + dA] = p.lastA[f]; h[b + aA] = sign(h[b + dA]);
  h[b + dA - 1] = (h[b + dA] - h[b + dA - 1]) | 0; h[b + aA - 1] = sign(h[b + dA - 1]);
  const prA = (Math.imul(h[b + dA], cA[0]) + Math.imul(h[b + dA - 1], cA[1]) + Math.imul(h[b + dA - 2], cA[2]) + Math.imul(h[b + dA - 3], cA[3])) | 0;
  h[b + dB] = (p.filterA[f ^ 1] - (Math.imul(p.filterB[f], 31) >> 5)) | 0; h[b + aB] = sign(h[b + dB]);
  h[b + dB - 1] = (h[b + dB] - h[b + dB - 1]) | 0; h[b + aB - 1] = sign(h[b + dB - 1]);
  p.filterB[f] = p.filterA[f ^ 1];
  const prB = (Math.imul(h[b + dB], cB[0]) + Math.imul(h[b + dB - 1], cB[1]) + Math.imul(h[b + dB - 2], cB[2]) + Math.imul(h[b + dB - 3], cB[3]) + Math.imul(h[b + dB - 4], cB[4])) | 0;
  p.lastA[f] = (decoded + (((prA + (prB >> 1)) | 0) >> 10)) | 0;
  p.filterA[f] = (p.lastA[f] + (Math.imul(p.filterA[f], 31) >> 5)) | 0;
  const s = sign(decoded);
  cA[0] += h[b + aA] * s; cA[1] += h[b + aA - 1] * s; cA[2] += h[b + aA - 2] * s; cA[3] += h[b + aA - 3] * s;
  cB[0] += h[b + aB] * s; cB[1] += h[b + aB - 1] * s; cB[2] += h[b + aB - 2] * s; cB[3] += h[b + aB - 3] * s; cB[4] += h[b + aB - 4] * s;
  return p.filterA[f];
}
function advance(p) { if (++p.b === HISTORY) { p.hist.copyWithin(0, HISTORY, HISTORY + PRED); p.b = 0; } }
function predStereo(p, d0, d1, n) {
  for (let i = 0; i < n; i++) {
    d0[i] = predUpdate(p, d0[i], 0, YDELAYA, YDELAYB, YADAPTA, YADAPTB);
    d1[i] = predUpdate(p, d1[i], 1, XDELAYA, XDELAYB, XADAPTA, XADAPTB);
    advance(p);
  }
}
function predMono(p, d0, n) {
  const h = p.hist, cA = p.coeffsA[0]; let cur = p.lastA[0];
  for (let i = 0; i < n; i++) {
    const A = d0[i], b = p.b;
    h[b + YDELAYA] = cur; h[b + YDELAYA - 1] = (h[b + YDELAYA] - h[b + YDELAYA - 1]) | 0;
    const pr = (Math.imul(h[b + YDELAYA], cA[0]) + Math.imul(h[b + YDELAYA - 1], cA[1]) + Math.imul(h[b + YDELAYA - 2], cA[2]) + Math.imul(h[b + YDELAYA - 3], cA[3])) | 0;
    cur = (A + (pr >> 10)) | 0;
    h[b + YADAPTA] = sign(h[b + YDELAYA]); h[b + YADAPTA - 1] = sign(h[b + YDELAYA - 1]);
    const s = sign(A);
    cA[0] += h[b + YADAPTA] * s; cA[1] += h[b + YADAPTA - 1] * s; cA[2] += h[b + YADAPTA - 2] * s; cA[3] += h[b + YADAPTA - 3] * s;
    advance(p);
    p.filterA[0] = (cur + (Math.imul(p.filterA[0], 31) >> 5)) | 0; d0[i] = p.filterA[0];
  }
  p.lastA[0] = cur;
}

// ---------- файл ----------
function info(fs, fd, fileSize) {
  const H = Buffer.alloc(Math.min(fileSize, 1 << 16)); fs.readSync(fd, H, 0, H.length, 0);
  let junk = 0;
  if (H.toString('latin1', 0, 3) === 'ID3') junk = 10 + ((H[6] & 127) << 21 | (H[7] & 127) << 14 | (H[8] & 127) << 7 | (H[9] & 127)) + (H[5] & 0x10 ? 10 : 0);
  const B = Buffer.alloc(256); fs.readSync(fd, B, 0, 256, junk);
  if (B.toString('latin1', 0, 4) !== 'MAC ') { const k = H.indexOf('MAC ', 0, 'latin1'); if (k < 0) throw new Error('Это не файл Monkey\'s Audio'); junk = k; fs.readSync(fd, B, 0, 256, junk); }
  const ver = B.readUInt16LE(4);
  if (ver < 3950) throw new Error('Файл APE старой версии ' + (ver / 1000).toFixed(2) + ' — такие не поддерживаются');
  const a = { ver, junk };
  let o;
  if (ver >= 3980) {
    a.descLen = B.readUInt32LE(8); a.headLen = B.readUInt32LE(12); a.seekLen = B.readUInt32LE(16); a.wavHead = B.readUInt32LE(20); a.wavTail = B.readUInt32LE(32);
    o = a.descLen;
    a.level = B.readUInt16LE(o); a.flags = B.readUInt16LE(o + 2); a.bpf = B.readUInt32LE(o + 4); a.finalBlocks = B.readUInt32LE(o + 8); a.frames = B.readUInt32LE(o + 12);
    a.bits = B.readUInt16LE(o + 16); a.channels = B.readUInt16LE(o + 18); a.rate = B.readUInt32LE(o + 20);
  } else {
    a.descLen = 0; a.headLen = 32;
    a.level = B.readUInt16LE(6); a.flags = B.readUInt16LE(8); a.channels = B.readUInt16LE(10); a.rate = B.readUInt32LE(12);
    a.wavHead = B.readUInt32LE(16); a.wavTail = B.readUInt32LE(20); a.frames = B.readUInt32LE(24); a.finalBlocks = B.readUInt32LE(28);
    o = 32;
    if (a.flags & 4) { o += 4; a.headLen += 4; }   // пиковый уровень
    if (a.flags & 16) { a.seekLen = B.readUInt32LE(o) * 4; a.headLen += 4; } else a.seekLen = a.frames * 4;
    a.bits = a.flags & 1 ? 8 : a.flags & 8 ? 24 : 16;
    a.bpf = 73728 * 4;
  }
  if (a.channels < 1 || a.channels > 2) throw new Error('APE: поддерживаются моно и стерео');
  if (![8, 16, 24].includes(a.bits)) throw new Error('APE: ' + a.bits + ' бит не поддерживается');
  if (a.level % 1000 || a.level < 1000 || a.level > 5000) throw new Error('APE: неизвестный уровень сжатия ' + a.level);
  if (!a.frames) throw new Error('APE: в файле нет звука');
  const first = junk + a.descLen + a.headLen + a.seekLen + a.wavHead;
  // в старых файлах (до 3.98) таблица перемотки идёт после сохранённого заголовка WAV
  const seekAt = junk + a.descLen + a.headLen + (ver < 3980 && !(a.flags & 32) ? a.wavHead : 0);
  const S = Buffer.alloc(a.seekLen); fs.readSync(fd, S, 0, a.seekLen, seekAt);
  const frames = [];
  for (let i = 0; i < a.frames; i++) {
    const pos = i === 0 ? first : S.readUInt32LE(i * 4) + junk;
    frames.push({ pos, n: i === a.frames - 1 ? a.finalBlocks : a.bpf, start: i * a.bpf });
  }
  for (let i = 0; i < frames.length; i++) {
    const f = frames[i];
    let size = i < frames.length - 1 ? frames[i + 1].pos - f.pos : fileSize - f.pos - a.wavTail;
    if (i === frames.length - 1) { size -= size & 3; if (size <= 0) size = a.finalBlocks * 8; }
    const skip = (f.pos - frames[0].pos) & 3;
    f.off = f.pos - skip; f.skip = skip; f.len = (size + skip + 3) & ~3;
  }
  const total = (a.frames - 1) * a.bpf + a.finalBlocks;
  return { codec: 'APE', ver, level: a.level, rate: a.rate, channels: a.channels, bits: a.bits, float: false, total, frames, dataEnd: fileSize - a.wavTail };
}

// кадр (байты файла от f.off длиной f.len) → каналы
function decodeFrame(raw, fr, inf) {
  const n = fr.n, len = raw.length & ~3, d = Buffer.alloc(raw.length + 8);
  for (let i = 0; i < len; i += 4) { d[i] = raw[i + 3]; d[i + 1] = raw[i + 2]; d[i + 2] = raw[i + 1]; d[i + 3] = raw[i]; }
  const ver = inf.ver, f = new Frame(d, fr.skip, ver); f.end = raw.length;
  let crc = f.be32(), flags = 0;
  if (ver > 3820 && crc & 0x80000000) flags = f.be32();
  f.p++; f.start();
  const fset = inf.level / 1000 - 1;
  heap = 0;
  const filt = [0, 1].map(() => ORDERS[fset].map((o) => mkFilter(o)));
  const pred = mkPred(); const rY = { k: 10, ksum: 16384 }, rX = { k: 10, ksum: 16384 };
  const ch = [new Int32Array(n), new Int32Array(n)];
  const stereo = inf.channels === 2 && !(flags & 4);
  const LOOP = 4608;
  for (let at = 0; at < n; at += LOOP) {
    const cnt = Math.min(LOOP, n - at); const d0 = ch[0].subarray(at, at + cnt), d1 = ch[1].subarray(at, at + cnt);
    if (!stereo) {
      if (flags & 3) continue;   // тишина
      for (let i = 0; i < cnt; i++) d0[i] = ver >= 3990 ? value3990(f, rY) : value3900(f, rY, ver);
      for (let L = 0; L < ORDERS[fset].length; L++) applyFilter(filt[0][L], d0, cnt, FRAC[fset][L], ver);
      predMono(pred, d0, cnt);
      if (inf.channels === 2) d1.set(d0);
    } else {
      if ((flags & 3) === 3) continue;
      if (ver >= 3990) { for (let i = 0; i < cnt; i++) { d0[i] = value3990(f, rY); d1[i] = value3990(f, rX); } }
      else { for (let i = 0; i < cnt; i++) { d0[i] = value3900(f, rY, ver); d1[i] = value3900(f, rX, ver); } }
      for (let L = 0; L < ORDERS[fset].length; L++) { applyFilter(filt[0][L], d0, cnt, FRAC[fset][L], ver); applyFilter(filt[1][L], d1, cnt, FRAC[fset][L], ver); }
      predStereo(pred, d0, d1, cnt);
      for (let i = 0; i < cnt; i++) { const left = (d1[i] - Math.trunc(d0[i] / 2)) | 0; const right = (left + d0[i]) | 0; d0[i] = left; d1[i] = right; }
    }
    if (f.err) throw new Error('APE: кадр повреждён');
  }
  return { ch: inf.channels === 2 ? ch : [ch[0]], n };
}
module.exports = { info, decodeFrame, simd: () => !!W, noSimd: () => { W = null; } };
