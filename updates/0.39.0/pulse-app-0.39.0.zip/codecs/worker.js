// Поток-декодер: APE и WavPack разжимаются здесь, чтобы главный процесс программы не тормозил.
// Сообщения: { op: 'open', id, path } → { id, info } ; { op: 'frame', id, path, i } → { id, pcm, n } ; { op: 'close', path }.
// pcm — готовые байты для WAV: 8 бит без знака, 16/24 бит со знаком, 32 бит — float.
'use strict';
const { parentPort } = require('worker_threads');
const fs = require('fs');
const path = require('path');
const C = { '.ape': require('./ape'), '.wv': require('./wv') };

const open = new Map();   // путь → { fd, inf, mod, used }
function get(p) {
  let o = open.get(p);
  if (!o) {
    const mod = C[path.extname(p).toLowerCase()]; if (!mod) throw new Error('Неизвестный формат');
    const fd = fs.openSync(p, 'r'); const size = fs.fstatSync(fd).size;
    try { o = { fd, inf: mod.info(fs, fd, size), mod, used: Date.now() }; } catch (e) { fs.closeSync(fd); throw e; }
    open.set(p, o);
    if (open.size > 6) { const old = [...open.entries()].sort((a, b) => a[1].used - b[1].used)[0]; if (old[0] !== p) { fs.closeSync(old[1].fd); open.delete(old[0]); } }
  }
  o.used = Date.now(); return o;
}
// выходной формат WAV для файла
function outFmt(inf) { return inf.float || inf.bits > 24 ? { bits: 32, float: true } : { bits: inf.bits, float: false }; }
function pack(ch, n, inf) {
  const of = outFmt(inf), C2 = ch.length, bps = of.bits / 8, buf = Buffer.allocUnsafe(n * C2 * bps); let o = 0;
  if (of.float) {
    const k = inf.float ? 1 : 1 / 2147483648;
    for (let i = 0; i < n; i++) for (let c = 0; c < C2; c++) { buf.writeFloatLE(ch[c][i] * k, o); o += 4; }
  } else if (of.bits === 16) { for (let i = 0; i < n; i++) for (let c = 0; c < C2; c++) { buf.writeInt16LE(Math.max(-32768, Math.min(32767, ch[c][i])), o); o += 2; } }
  else if (of.bits === 24) { for (let i = 0; i < n; i++) for (let c = 0; c < C2; c++) { const v = Math.max(-8388608, Math.min(8388607, ch[c][i])); buf[o] = v & 255; buf[o + 1] = (v >> 8) & 255; buf[o + 2] = (v >> 16) & 255; o += 3; } }
  else { for (let i = 0; i < n; i++) for (let c = 0; c < C2; c++) { buf[o++] = (ch[c][i] + 128) & 255; } }
  return buf;
}
parentPort.on('message', (m) => {
  try {
    if (m.op === 'close') { const o = open.get(m.path); if (o) { fs.closeSync(o.fd); open.delete(m.path); } return; }
    const o = get(m.path);
    if (m.op === 'open') {
      const { frames, ...rest } = o.inf; const of = outFmt(o.inf);
      parentPort.postMessage({ id: m.id, info: { ...rest, out: of, frames: frames.map((f) => [f.start, f.n]) } });
    } else if (m.op === 'frame') {
      const fr = o.inf.frames[m.i]; if (!fr) throw new Error('Нет такого кадра');
      const b = Buffer.alloc(fr.len); fs.readSync(o.fd, b, 0, fr.len, fr.off);
      const { ch, n } = o.inf.codec === 'APE' ? o.mod.decodeFrame(b, fr, o.inf) : o.mod.decodeFrame(b);
      while (ch.length < o.inf.channels) ch.push(new Int32Array(n));
      if (ch.length > o.inf.channels) ch.length = o.inf.channels;
      const pcm = pack(ch, fr.n, o.inf);   // всегда ровно fr.n отсчётов: недостающее — тишина, чтобы не съехали позиции
      const ab = pcm.buffer.slice(pcm.byteOffset, pcm.byteOffset + pcm.length);
      parentPort.postMessage({ id: m.id, pcm: ab, n: fr.n, short: n < fr.n }, [ab]);
    }
  } catch (e) { parentPort.postMessage({ id: m.id, err: String((e && e.message) || e) }); }
});
