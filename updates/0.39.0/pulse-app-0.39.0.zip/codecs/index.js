// APE и WavPack для окна программы: встроенный движок (Chromium) этих кодеков не знает, поэтому главный процесс
// отдаёт такие файлы как обычный WAV, разжимая их на лету в отдельном потоке (worker.js).
// openDecoded(путь) → { size, read(buf, off, len, pos), close(), info } — тот же вид, что у openR в local.js:
// отдача по кускам и перемотка (Range) работают как с любым файлом. Кадры декодируются по требованию,
// последние несколько держатся в памяти, следующий готовится заранее.
'use strict';
const path = require('path');
const { Worker } = require('worker_threads');

const EXT = new Set(['.ape', '.wv']);
const isDecoded = (p) => EXT.has(path.extname(String(p)).toLowerCase());

let worker = null, seq = 0; const wait = new Map();
function w() {
  if (worker) return worker;
  worker = new Worker(path.join(__dirname, 'worker.js'));
  worker.on('message', (m) => { const r = wait.get(m.id); if (!r) return; wait.delete(m.id); if (!wait.size) worker.unref(); m.err ? r.no(new Error(m.err)) : r.ok(m); });
  const fail = (e) => { for (const r of wait.values()) r.no(e instanceof Error ? e : new Error('декодер остановился')); wait.clear(); worker = null; };
  worker.on('error', fail); worker.on('exit', () => fail(new Error('декодер остановился')));
  worker.unref();
  return worker;
}
// пока ждём ответа — поток держит процесс (иначе Node мог бы завершиться посреди разжатия)
function ask(msg) { return new Promise((ok, no) => { const id = ++seq; wait.set(id, { ok, no }); const W = w(); W.ref(); W.postMessage({ ...msg, id }); }); }

// сведения о файлах: путь → Promise<info> (таблица кадров нужна, чтобы по байту WAV найти кадр)
const infos = new Map();
function info(p) {
  let v = infos.get(p);
  if (!v) { v = ask({ op: 'open', path: p }).then((m) => m.info); infos.set(p, v); v.catch(() => infos.delete(p)); if (infos.size > 64) infos.delete(infos.keys().next().value); }
  return v;
}
// разжатые кадры: «путь#номер» → Promise<Buffer>; держим немного — этого хватает и на перемотку назад
const frames = new Map(); const KEEP = 6;
function frame(p, i) {
  const k = p + '#' + i; let v = frames.get(k);
  if (v) { frames.delete(k); frames.set(k, v); return v; }
  v = ask({ op: 'frame', path: p, i }).then((m) => Buffer.from(m.pcm));
  frames.set(k, v); v.catch(() => frames.delete(k));
  while (frames.size > KEEP) frames.delete(frames.keys().next().value);
  return v;
}

function wavHeader(inf, dataLen) {
  const { bits, float } = inf.out, C = inf.channels, ba = C * bits / 8;
  const h = Buffer.alloc(44);
  h.write('RIFF', 0, 'latin1'); h.writeUInt32LE(Math.min(0xffffffff, 36 + dataLen), 4); h.write('WAVEfmt ', 8, 'latin1');
  h.writeUInt32LE(16, 16); h.writeUInt16LE(float ? 3 : 1, 20); h.writeUInt16LE(C, 22); h.writeUInt32LE(inf.rate, 24);
  h.writeUInt32LE(inf.rate * ba, 28); h.writeUInt16LE(ba, 32); h.writeUInt16LE(bits, 34);
  h.write('data', 36, 'latin1'); h.writeUInt32LE(Math.min(0xffffffff, dataLen), 40);
  return h;
}

async function openDecoded(p) {
  const inf = await info(p);
  const ba = inf.channels * inf.out.bits / 8, dataLen = inf.total * ba, H = wavHeader(inf, dataLen), F = inf.frames;
  const at = (s) => { let lo = 0, hi = F.length - 1; while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (F[mid][0] <= s) lo = mid; else hi = mid - 1; } return lo; };
  return {
    size: 44 + dataLen, info: inf,
    close: async () => {},
    read: async (b, o, l, pos) => {
      let done = 0;
      if (pos < 44) { const n = Math.min(l, 44 - pos); H.copy(b, o, pos, pos + n); done = n; pos += n; }
      while (done < l && pos < 44 + dataLen) {
        const s = Math.floor((pos - 44) / ba), i = at(s), [start, n] = F[i];
        const pcm = await frame(p, i);
        if (i + 1 < F.length) frame(p, i + 1).catch(() => {});   // следующий кадр — заранее
        const from = pos - 44 - start * ba, k = Math.min(l - done, n * ba - from, pcm.length - from);
        if (k <= 0) break;
        pcm.copy(b, o + done, from, from + k); done += k; pos += k;
      }
      return { bytesRead: done };
    },
  };
}
// длительность и формат для списка музыки (без разжатия звука)
async function probe(p) { const inf = await info(p); return { codec: inf.codec === 'APE' ? 'APE' : 'WavPack', sr: inf.rate, ch: inf.channels, bits: inf.bits, dur: inf.rate ? inf.total / inf.rate : 0, lossy: !!inf.lossy, dataEnd: inf.dataEnd }; }
function forget(p) { infos.delete(p); for (const k of [...frames.keys()]) if (k.startsWith(p + '#')) frames.delete(k); if (worker) worker.postMessage({ op: 'close', path: p }); }

module.exports = { isDecoded, openDecoded, probe, forget };
