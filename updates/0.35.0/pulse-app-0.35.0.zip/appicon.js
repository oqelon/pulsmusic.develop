// Значок программы, когда она закрыта.
// Пока «Пульс» запущен, значок задаёт он сам (окно, панель задач, Dock). Закрытую программу система показывает
// по файлам: на Windows — по ярлыкам (рабочий стол, «Пуск», закреплённые на панели задач) и их файлу значка,
// на Mac — по значку самого Pulse.app. Обновление меняет только файлы программы, поэтому здесь значок один раз
// переносится и туда. Повторяется, только если сменится ICON_V.
//   Windows: новый файл pulse-<ICON_V>.ico рядом с Pulse.exe (новое имя — чтобы Windows не взяла старую картинку
//   из своего кэша), все ярлыки на Pulse.exe переводятся на него, кэш значков обновляется (ie4uinit).
//   Mac: значок ставится на Pulse.app так же, как через «Свойства» в Finder (подпись программы не меняется),
//   Dock перечитывает значки один раз — при выходе из программы.
'use strict';
const { app } = require('electron');
const fs = require('fs');
const path = require('path');
const { execFile, spawn } = require('child_process');

const ICON_V = 5;   // поднять при смене значка (5 — плоская арбузная плитка с белым знаком, 0.35)

function start(log) {
  if (!app.isPackaged) return;
  const stFile = path.join(app.getPath('userData'), 'appicon.json');
  let st = {}; try { st = JSON.parse(fs.readFileSync(stFile, 'utf8')) || {}; } catch {}
  if (st.v === ICON_V) return;
  const done = (extra) => { try { fs.writeFileSync(stFile, JSON.stringify({ v: ICON_V, ...extra })); } catch {} };
  setTimeout(() => { try { (process.platform === 'win32' ? win : process.platform === 'darwin' ? mac : () => {})(log, done); } catch (e) { log('значок закрытой программы: не получилось —', e && e.message); } }, 8000).unref();
}

function win(log, done) {
  const exe = process.execPath; const dir = path.dirname(exe);
  if (path.basename(exe).toLowerCase() !== 'pulse.exe') return;
  const src = path.join(__dirname, 'build', 'icon.ico'); const ico = path.join(dir, 'pulse-' + ICON_V + '.ico');
  fs.copyFileSync(src, ico); try { fs.copyFileSync(src, path.join(dir, 'pulse.ico')); } catch {}
  for (const f of fs.readdirSync(dir)) if (/^pulse-\d+\.ico$/i.test(f) && f.toLowerCase() !== path.basename(ico).toLowerCase()) fs.promises.rm(path.join(dir, f), { force: true }).catch(() => {});
  const q = (s) => "'" + String(s).replace(/'/g, "''") + "'";
  const ps = `$ErrorActionPreference='SilentlyContinue'; $ws=New-Object -ComObject WScript.Shell; $exe=${q(exe)}; $ico=${q(ico)}; $n=0
$dirs=@([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('CommonDesktopDirectory'),[Environment]::GetFolderPath('Programs'),[Environment]::GetFolderPath('CommonPrograms'),(Join-Path $env:APPDATA 'Microsoft\\Internet Explorer\\Quick Launch\\User Pinned\\TaskBar'),(Join-Path $env:APPDATA 'Microsoft\\Internet Explorer\\Quick Launch\\User Pinned\\StartMenu'),(Join-Path $env:APPDATA 'Microsoft\\Internet Explorer\\Quick Launch'))
foreach($d in $dirs){ if($d -and (Test-Path $d)){ Get-ChildItem -LiteralPath $d -Filter *.lnk -Recurse | ForEach-Object { try { $s=$ws.CreateShortcut($_.FullName); if($s.TargetPath -and ($s.TargetPath -ieq $exe)){ $s.IconLocation=$ico+',0'; $s.Save(); $n++ } } catch {} } } }
Write-Output $n`;
  execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', ps], { windowsHide: true, timeout: 60000 }, (err, out) => {
    const n = parseInt(String(out || '').trim(), 10) || 0;
    execFile('ie4uinit.exe', ['-show'], { windowsHide: true }, () => {});
    log('значок ярлыков:', err ? 'ошибка — ' + err.message : 'обновлено ярлыков — ' + n);
    if (!err) done({ n });
  });
}

function mac(log, done) {
  const bundle = path.resolve(process.execPath, '..', '..', '..');
  if (!/\.app$/i.test(bundle)) return;
  const png = path.join(__dirname, 'build', 'icon-mac.png');
  const js = `ObjC.import('AppKit'); var img = $.NSImage.alloc.initWithContentsOfFile(${JSON.stringify(png)}); img.isNil() ? 'noimg' : ($.NSWorkspace.sharedWorkspace.setIconForFileOptions(img, ${JSON.stringify(bundle)}, 0) ? 'ok' : 'no')`;
  execFile('/usr/bin/osascript', ['-l', 'JavaScript', '-e', js], { timeout: 30000 }, (err, out) => {
    const r = String(out || '').trim();
    if (err || r !== 'ok') { log('значок Pulse.app: не получилось —', err ? err.message : r, '(нужен доступ на запись к', bundle + ')'); return; }
    try { const t = new Date(); fs.utimesSync(bundle, t, t); } catch {}
    done({}); log('значок Pulse.app обновлён');
    // Dock держит значки в памяти — перечитает при выходе из программы (один раз)
    app.once('will-quit', () => { try { spawn('/usr/bin/killall', ['Dock'], { detached: true, stdio: 'ignore' }).unref(); } catch {} });
  });
}
module.exports = { start };
