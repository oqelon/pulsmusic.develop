// Статус «Слушает Пульс» в Discord (Rich Presence), главный процесс.
//
// • Связь — только с приложением Discord на этом же компьютере, через его локальный канал для статусов
//   (Windows: \\?\pipe\discord-ipc-N, Mac: $TMPDIR/discord-ipc-N). Ни входа в аккаунт Discord, ни токенов,
//   ни нашего сервера. Нужен только публичный номер приложения «Пульс» в Discord (Application ID) — сервер
//   «Пульса» отдаёт его в /s/config, поэтому его можно поменять без выпуска новой версии.
// • Окно присылает, что играет (set), и включён ли статус (enable). Пауза — статус убирается. Обновления не чаще
//   раза в 1,5 с (у Discord лимит — 5 изменений за 20 секунд).
// • Discord не запущен — тихо пробуем снова раз в 20 секунд, пока статус включён.
'use strict';
const net = require('net');
const path = require('path');
const crypto = require('crypto');

const SITE = 'https://oqelon.github.io/pulsmusic.develop/pc/';                       // кнопка «Скачать «Пульс»»
// звезда «Пульса»: прямо из репозитория (не зависит от сайта на GitHub Pages)
const ICON = 'https://raw.githubusercontent.com/oqelon/pulsmusic.develop/main/docs/assets/apple-touch-icon.png';

let log = () => {}, configUrl = '', appId = '', enabled = false;
let legacy = false;   // Discord не понял новые поля (старая версия) — шлём без них
let sock = null, ready = false, buf = Buffer.alloc(0), retryT = 0, sendT = 0, lastSent = '', want = null, state = 'off', onState = () => {};
const setState = (s) => { if (s !== state) { state = s; onState(s); } };

function pipePath(i) {
  if (process.platform === 'win32') return '\\\\?\\pipe\\discord-ipc-' + i;
  const base = process.env.XDG_RUNTIME_DIR || process.env.TMPDIR || process.env.TMP || process.env.TEMP || '/tmp';
  return path.join(base, 'discord-ipc-' + i);
}
function frame(op, obj) { const j = Buffer.from(JSON.stringify(obj), 'utf8'); const h = Buffer.alloc(8); h.writeInt32LE(op, 0); h.writeInt32LE(j.length, 4); return Buffer.concat([h, j]); }

function drop(why) {
  if (sock) { try { sock.destroy(); } catch {} }
  sock = null; ready = false; buf = Buffer.alloc(0); lastSent = '';
  if (why) log('discord:', why);
  if (enabled && appId) { setState('wait'); clearTimeout(retryT); retryT = setTimeout(connect, 20000); } else setState(appId ? 'off' : 'noid');
}
function tryPipe(i) {
  return new Promise((ok) => {
    const s = net.createConnection(pipePath(i));
    const t = setTimeout(() => { s.destroy(); ok(null); }, 1500);
    s.once('connect', () => { clearTimeout(t); ok(s); });
    s.once('error', () => { clearTimeout(t); ok(null); });
  });
}
async function connect() {
  clearTimeout(retryT);
  if (sock || !enabled || !appId) return;
  let s = null; for (let i = 0; i < 10 && !s; i++) s = await tryPipe(i);
  if (!s) { drop(); return; }
  if (!enabled || sock) { s.destroy(); return; }
  sock = s; setState('wait');
  s.on('data', (d) => { buf = Buffer.concat([buf, d]); parse(); });
  s.on('error', () => drop());
  s.on('close', () => { if (sock === s) drop(); });
  s.write(frame(0, { v: 1, client_id: appId }));
}
function parse() {
  while (buf.length >= 8) {
    const op = buf.readInt32LE(0), len = buf.readInt32LE(4); if (buf.length < 8 + len) return;
    let m = null; try { m = JSON.parse(buf.subarray(8, 8 + len).toString('utf8')); } catch {}
    buf = buf.subarray(8 + len);
    if (op === 3 && sock) sock.write(frame(4, m || {}));                  // ping → pong
    else if (op === 2) { drop('закрыто: ' + (m && m.message)); if (m && /client.?id/i.test(String(m.message))) { setState('badid'); clearTimeout(retryT); } return; }
    else if (op === 1 && m) {
      if (m.evt === 'READY') { ready = true; setState('on'); push(true); }
      else if (m.evt === 'ERROR') { log('discord: ошибка', m.data && m.data.message); if (!legacy) { legacy = true; push(true); } }
    }
  }
}

// что показать: { title, artist, album, cover, dur, pos, playing, yid, albumId } или null
function activity(t) {
  if (!t || !t.playing || !t.title) return null;
  const pad = (s, n) => { s = String(s || '').trim().slice(0, n); return s.length < 2 ? (s + '  ').slice(0, 2) : s; };
  // обложка Яндекса 400×400 (быстрее грузится у Discord, чем 1000×1000); своих файлов в интернете нет — звезда «Пульса»
  let cover = typeof t.cover === 'string' && /^https:\/\//.test(t.cover) && t.cover.length <= 256 ? t.cover.replace(/\/\d+x\d+(?=$|\?)/, '/400x400') : ICON;
  // status_display_type 1: в строке статуса «Слушает <исполнитель>», а не «Слушает Пульс»
  const a = { type: 2, details: pad(t.title, 128), state: pad(t.artist || 'Неизвестный исполнитель', 128), instance: false, ...(legacy ? {} : { status_display_type: 1 }),
    assets: { large_image: cover, large_text: pad(t.album || t.title, 128), small_image: ICON, small_text: 'Пульс' },
    buttons: [{ label: 'Скачать «Пульс»', url: SITE }] };
  if (t.yid && /^\d+$/.test(String(t.yid))) a.buttons.push({ label: 'Открыть в Яндекс Музыке', url: 'https://music.yandex.ru/' + (t.albumId && /^\d+$/.test(String(t.albumId)) ? 'album/' + t.albumId + '/' : '') + 'track/' + t.yid });
  if (t.dur > 0) { const now = Date.now(), pos = Math.max(0, Math.min(t.dur, t.pos || 0)); a.timestamps = { start: Math.round(now - pos * 1000), end: Math.round(now + (t.dur - pos) * 1000) }; }
  return a;
}
function push(force) {
  clearTimeout(sendT);
  sendT = setTimeout(() => {
    if (!sock || !ready) return;
    const act = enabled ? activity(want) : null;
    // одно и то же (тот же трек, та же позиция ±2 с) — не дёргаем Discord
    const key = act ? [act.details, act.state, act.assets.large_image, act.timestamps ? Math.round(act.timestamps.start / 2000) : 0].join('|') : '-';
    if (!force && key === lastSent) return; lastSent = key;
    const args = { pid: process.pid }; if (act) args.activity = act;
    try { sock.write(frame(1, { cmd: 'SET_ACTIVITY', args, nonce: crypto.randomUUID() })); } catch (e) { drop('не отправил: ' + e.message); }
  }, force ? 50 : 1500);
}

async function loadConfig() {
  try {
    const r = await fetch(configUrl, { signal: AbortSignal.timeout(10000) }); const c = await r.json();
    const id = c && typeof c.discord === 'string' && /^\d{15,22}$/.test(c.discord) ? c.discord : '';
    if (id !== appId) { appId = id; drop(); if (enabled) connect(); }
  } catch {}
}

function setup({ log: l, sec, socialUrl }) {
  log = l || log; configUrl = socialUrl + '/s/config';
  sec.handle('discord:enable', (_e, v) => { enabled = !!v; if (enabled) { if (!appId) loadConfig(); connect(); push(true); } else { push(true); setTimeout(() => { if (!enabled) drop(); }, 400); } return state; });
  sec.handle('discord:set', (_e, t) => { want = t && typeof t === 'object' ? t : null; push(false); return state; });
  sec.handle('discord:state', () => state);
  onState = (s) => { try { for (const w of require('electron').BrowserWindow.getAllWindows()) if (!w.isDestroyed()) w.webContents.send('discord:state', s); } catch {} };
  loadConfig(); setInterval(loadConfig, 6 * 3600e3).unref();
}
module.exports = { setup, activity, SITE };
