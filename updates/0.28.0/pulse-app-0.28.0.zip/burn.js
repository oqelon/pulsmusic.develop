// Запись аудио-CD (главный процесс). Звук уже переведён окном в формат CD — 44,1 кГц, 16 бит, стерео (см.
// src/services/cdburn.js); здесь он складывается во временную папку и записывается встроенными средствами системы:
//  • Windows — служба записи дисков Windows (IMAPI2) через PowerShell: «трек за треком» (TAO), пауза 2 с между треками;
//  • Mac — системная утилита drutil (drutil burn -audio).
// Ничего дополнительно ставить не нужно. Временные файлы удаляются после записи и при выходе из программы.
'use strict';
const { app, BrowserWindow } = require('electron');
const { spawn } = require('child_process');
const fs = require('fs'); const fsp = fs.promises;
const path = require('path'); const os = require('os');

let log = () => {};
const IS_WIN = process.platform === 'win32', IS_MAC = process.platform === 'darwin';
const root = () => path.join(os.tmpdir(), 'pulse-cd');
let job = null;   // { id, dir, n, proc, stage }
const send = (v) => { for (const w of BrowserWindow.getAllWindows()) if (!w.isDestroyed()) w.webContents.send('cd:progress', v); };

// ---------- Windows: сценарии PowerShell (только латиница; вывод — построчно, в UTF-8) ----------
const PS_HEAD = "$ErrorActionPreference='Stop'\n[Console]::OutputEncoding=[Text.Encoding]::UTF8\n";
const PS_LIST = PS_HEAD + `
try { $dm = New-Object -ComObject IMAPI2.MsftDiscMaster2 } catch { Write-Output 'END'; exit 0 }
foreach ($id in $dm) {
  try {
    $r = New-Object -ComObject IMAPI2.MsftDiscRecorder2; $r.InitializeDiscRecorder($id)
    $name = (($r.VendorId + ' ' + $r.ProductId) -replace '\\s+', ' ').Trim()
    $letter = ''; if ($r.VolumePathNames) { $letter = [string]($r.VolumePathNames | Select-Object -First 1) }
    $media = 'none'; $free = 0
    $d = New-Object -ComObject IMAPI2.MsftDiscFormat2Data
    if (-not $d.IsRecorderSupported($r)) { $media = 'nowrite' }
    elseif ($d.IsCurrentMediaSupported($r)) {
      $d.Recorder = $r; $t = [int]$d.CurrentPhysicalMediaType; $blank = $d.MediaHeuristicallyBlank
      if ($t -eq 2 -or $t -eq 3) {
        if ($blank) { $media = 'blank'; $tao = New-Object -ComObject IMAPI2.MsftDiscFormat2TrackAtOnce; $tao.Recorder = $r; try { $free = [int]$tao.TotalSectorsOnMedia } catch { $free = 0 } }
        elseif ($t -eq 3) { $media = 'rw' } else { $media = 'used' }
      } else { $media = 'notcd' }
    }
    Write-Output ('DRIVE|' + $id + '|' + $name + '|' + $letter + '|' + $media + '|' + $free)
  } catch { Write-Output ('ERR|' + $_.Exception.Message) }
}
Write-Output 'END'
`;
const PS_BURN = PS_HEAD + `
$id = $env:PULSE_CD_ID; $dir = $env:PULSE_CD_DIR; $speed = [int]$env:PULSE_CD_SPEED; $erase = $env:PULSE_CD_ERASE -eq '1'
Add-Type -Language CSharp @"
using System; using System.Runtime.InteropServices; using System.Runtime.InteropServices.ComTypes;
public static class PulseCdStream {
  [DllImport("shlwapi.dll", CharSet = CharSet.Unicode, PreserveSig = false)]
  static extern void SHCreateStreamOnFileEx(string file, uint mode, uint attr, bool create, IntPtr tmpl, out IStream s);
  public static IStream Open(string f) { IStream s; SHCreateStreamOnFileEx(f, 0x20, 0x80, false, IntPtr.Zero, out s); return s; }
}
"@
try {
  $r = New-Object -ComObject IMAPI2.MsftDiscRecorder2; $r.InitializeDiscRecorder($id)
  try {
    if ($erase) { Write-Output 'STAGE|erase'; $e = New-Object -ComObject IMAPI2.MsftDiscFormat2Erase; $e.Recorder = $r; $e.ClientName = 'Pulse'; $e.FullErase = $false; $e.EraseMedia() }
    $tao = New-Object -ComObject IMAPI2.MsftDiscFormat2TrackAtOnce; $tao.Recorder = $r; $tao.ClientName = 'Pulse'
    if ($speed -gt 0) { try { $tao.SetWriteSpeed($speed * 75, $false) } catch {} }
    Write-Output 'STAGE|prepare'; $tao.PrepareMedia()
    $files = @(Get-ChildItem -LiteralPath $dir -Filter '*.pcm' | Sort-Object Name)
    $i = 0
    foreach ($f in $files) {
      $i++; Write-Output ('TRACK|' + $i + '|' + $files.Count)
      $s = [PulseCdStream]::Open($f.FullName); $tao.AddAudioTrack($s); [void][Runtime.InteropServices.Marshal]::ReleaseComObject($s)
    }
    Write-Output 'STAGE|finish'; $tao.ReleaseMedia()
  } finally { }
  Write-Output 'DONE'
} catch { Write-Output ('ERR|' + ('0x{0:X8}' -f $_.Exception.HResult) + '|' + $_.Exception.Message); exit 1 }
`;
const PS_EJECT = PS_HEAD + `
$r = New-Object -ComObject IMAPI2.MsftDiscRecorder2; $r.InitializeDiscRecorder($env:PULSE_CD_ID); try { $r.EjectMedia() } catch {}
Write-Output 'DONE'
`;
async function ps(script, env, onLine) {
  await fsp.mkdir(root(), { recursive: true });
  const f = path.join(root(), 'pulse-' + Math.random().toString(36).slice(2) + '.ps1');
  await fsp.writeFile(f, '﻿' + script, 'utf8');
  return new Promise((res) => {
    const p = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-STA', '-ExecutionPolicy', 'Bypass', '-File', f], { env: { ...process.env, ...env }, windowsHide: true });
    let buf = '', err = ''; const lines = [];
    const eat = (s) => { buf += s; let i; while ((i = buf.indexOf('\n')) >= 0) { const l = buf.slice(0, i).trim(); buf = buf.slice(i + 1); if (l) { lines.push(l); onLine && onLine(l); } } };
    p.stdout.setEncoding('utf8'); p.stdout.on('data', eat); p.stderr.setEncoding('utf8'); p.stderr.on('data', (s) => { err += s; });
    p.on('error', (e) => { err += String(e && e.message); });
    p.on('close', (code) => { eat('\n'); fsp.rm(f, { force: true }).catch(() => {}); res({ code, lines, err: err.trim() }); });
    if (job && env && env.PULSE_CD_DIR) job.proc = p;
  });
}
// ---------- Mac: drutil ----------
function run(cmd, args, onData) {
  return new Promise((res) => {
    const p = spawn(cmd, args); let out = '', err = '';
    p.stdout.setEncoding('utf8'); p.stdout.on('data', (s) => { out += s; onData && onData(s); });
    p.stderr.setEncoding('utf8'); p.stderr.on('data', (s) => { err += s; onData && onData(s); });
    p.on('error', (e) => { err += String(e && e.message); }); p.on('close', (code) => res({ code, out, err }));
    if (job && onData) job.proc = p;
  });
}
function macStatus(txt) {
  const g = (k) => { const m = new RegExp(k + ':\\s*([^\\n]*?)(\\s{2,}|\\n|$)').exec(txt); return m ? m[1].trim() : ''; };
  const type = g('Type'); const wr = g('Writability'); const free = /Space Free:\s*(\d+):(\d+):(\d+)/.exec(txt);
  let media = 'none';
  if (!type || /No Media/i.test(type)) media = 'none';
  else if (!/^CD-R/i.test(type)) media = 'notcd';
  else if (/blank/i.test(wr)) media = 'blank';
  else if (/CD-RW/i.test(type)) media = 'rw';
  else media = 'used';
  return { media, free: free ? (+free[1] * 60 + +free[2]) * 75 + +free[3] : 0 };
}

// ---------- для окна ----------
async function drives() {
  if (IS_WIN) {
    const r = await ps(PS_LIST, {});
    const out = r.lines.filter((l) => l.startsWith('DRIVE|')).map((l) => { const [, id, name, letter, media, free] = l.split('|'); return { id, name: name || 'Привод', letter: letter.replace(/\\$/, ''), media, mins: Math.floor((+free || 0) / 75 / 60) }; });
    if (!out.length && r.err) log('CD: список приводов', r.err.slice(0, 300));
    return { ok: true, drives: out };
  }
  if (IS_MAC) {
    const l = await run('drutil', ['list']); if (l.code) return { ok: true, drives: [] };
    const rows = l.out.split('\n').filter((x) => /^\s*\d+\s+/.test(x));
    const out = [];
    for (const row of rows) {
      const n = row.trim().split(/\s+/)[0]; const name = row.trim().replace(/^\d+\s+/, '').replace(/\s{2,}/g, ' ').trim();
      const s = await run('drutil', ['-drive', n, 'status']); const st = macStatus(s.out);
      out.push({ id: n, name, letter: '', media: st.media, mins: Math.floor(st.free / 75 / 60) });
    }
    return { ok: true, drives: out };
  }
  return { ok: false, err: 'Запись дисков есть только на Windows и Mac' };
}
async function begin(n) {
  if (job && job.proc) return { ok: false, err: 'Уже идёт запись' };
  await cleanup();
  const id = Date.now().toString(36); const dir = path.join(root(), 'job-' + id);
  await fsp.mkdir(dir, { recursive: true }); job = { id, dir, n: Math.max(1, Math.min(99, n | 0)) };
  return { ok: true, id };
}
// один трек: 16 бит, 44,1 кГц, стерео, длина кратна сектору CD (2352 байта). Windows берёт «сырой» звук, Mac — WAV.
async function put(id, i, data) {
  if (!job || job.id !== id) return { ok: false, err: 'Нет задания' };
  const b = Buffer.from(data); if (!b.length || b.length % 2352) return { ok: false, err: 'Неверный размер' };
  const name = String(i + 1).padStart(2, '0');
  if (IS_MAC) { const h = Buffer.alloc(44); h.write('RIFF', 0, 'latin1'); h.writeUInt32LE(36 + b.length, 4); h.write('WAVEfmt ', 8, 'latin1'); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(2, 22); h.writeUInt32LE(44100, 24); h.writeUInt32LE(176400, 28); h.writeUInt16LE(4, 32); h.writeUInt16LE(16, 34); h.write('data', 36, 'latin1'); h.writeUInt32LE(b.length, 40);
    await fsp.writeFile(path.join(job.dir, name + '.wav'), Buffer.concat([h, b])); }
  else await fsp.writeFile(path.join(job.dir, name + '.pcm'), b);
  return { ok: true };
}
const ERR = { '0xC0AA0202': 'Диск не чистый — вставьте чистый CD-R или CD-RW', '0xC0AA0204': 'В приводе нет диска', '0xC0AA0205': 'Привод не может записать такой диск', '0xC0AA0206': 'Нет доступа к приводу — его занимает другая программа', '0xC0AA0209': 'Диск закончился — треки не поместились', '0xC0AA0405': 'Звука больше, чем помещается на диск', '0xC0AA0210': 'Привод занят другой программой' };
async function burn(id, o) {
  if (!job || job.id !== id) return { ok: false, err: 'Нет задания' };
  const speed = Math.max(0, Math.min(52, +o.speed || 0)); const erase = !!o.erase;
  send({ stage: 'prepare' });
  try {
    if (IS_WIN) {
      let err = '';
      const r = await ps(PS_BURN, { PULSE_CD_ID: String(o.drive || ''), PULSE_CD_DIR: job.dir, PULSE_CD_SPEED: String(speed), PULSE_CD_ERASE: erase ? '1' : '0' }, (l) => {
        const a = l.split('|');
        if (a[0] === 'STAGE') send({ stage: a[1] });
        else if (a[0] === 'TRACK') send({ stage: 'write', track: +a[1], n: +a[2] });
        else if (a[0] === 'ERR') err = (ERR[a[1]] || a.slice(2).join('|') || 'Ошибка записи') + (ERR[a[1]] ? '' : ' (' + a[1] + ')');
      });
      job.proc = null;
      if (r.code || !r.lines.includes('DONE')) { log('CD: запись', err || r.err.slice(0, 400)); return { ok: false, err: err || 'Не удалось записать диск' }; }
      return { ok: true };
    }
    if (IS_MAC) {
      const args = ['-drive', String(o.drive || '1'), 'burn', '-audio', '-noverify'];
      if (speed) args.push('-speed', speed + 'x'); if (erase) args.push('-erase');
      args.push(job.dir);
      send({ stage: 'write', track: 0, n: job.n });
      const r = await run('drutil', args, (s) => { const m = /(\d{1,3})%/.exec(s); if (m) send({ stage: 'write', pct: Math.min(100, +m[1]) }); });
      job.proc = null;
      if (r.code) { log('CD: drutil', (r.err || r.out).slice(-400)); return { ok: false, err: (r.err || r.out).trim().split('\n').pop() || 'Не удалось записать диск' }; }
      return { ok: true };
    }
    return { ok: false, err: 'Запись дисков есть только на Windows и Mac' };
  } finally { cleanup(); }
}
async function eject(drive) {
  if (IS_WIN) { await ps(PS_EJECT, { PULSE_CD_ID: String(drive || '') }); return true; }
  if (IS_MAC) { await run('drutil', ['-drive', String(drive || '1'), 'eject']); return true; }
  return false;
}
// отмена — только пока идёт подготовка звука: прерванная запись портит CD-R
function cancel() { if (job && job.proc) return false; cleanup(); return true; }
async function cleanup() { const j = job; job = null; if (j) await fsp.rm(j.dir, { recursive: true, force: true }).catch(() => {}); }

function setup(o) {
  log = (o && o.log) || log; const sec = o.sec;
  sec.handle('cd:drives', () => drives().catch((e) => ({ ok: false, err: String(e && e.message) })));
  sec.handle('cd:begin', (_e, n) => begin(n));
  sec.handle('cd:put', (_e, id, i, data) => put(id, i | 0, data));
  sec.handle('cd:burn', (_e, id, opts) => burn(id, opts || {}));
  sec.handle('cd:eject', (_e, d) => eject(d));
  sec.handle('cd:cancel', () => cancel());
  app.on('will-quit', () => { try { fs.rmSync(root(), { recursive: true, force: true }); } catch {} });
  fsp.rm(root(), { recursive: true, force: true }).catch(() => {});   // хвосты прошлых запусков
}
module.exports = { setup };
