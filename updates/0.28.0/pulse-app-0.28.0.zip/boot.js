// Загрузчик «Пульса» для Mac.
//
// Программа на Mac подписана, и менять файлы внутри Pulse.app нельзя — macOS сочтёт её повреждённой.
// Поэтому обновления ставятся рядом, в папку пользователя: ~/Library/Application Support/Pulse/ota/<версия>/.
// Загрузчик при каждом запуске смотрит туда: если там версия новее встроенной и ей подходит этот движок
// (Electron), запускается она, иначе — встроенная.
//
// Защита от неудачного обновления: перед запуском версии из ota/ загрузчик отмечает попытку, а программа снимает
// отметку, как только показала окно. Две попытки подряд без окна — версия считается сломанной, и «Пульс»
// возвращается к встроенной (или предыдущей) версии.
//
// Подпись: рядом с каждой версией в ota/ лежат её пакет (.pulse-pkg.zip) и подпись разработчика (.pulse-sig.json).
// При каждом запуске загрузчик проверяет подпись (Ed25519, открытый ключ — в updsign.js внутри подписанной Pulse.app),
// контрольную сумму пакета и то, что файлы в папке байт в байт совпадают с пакетом и лишних нет. Не сошлось —
// версия не запускается, открывается встроенная (подменить файлы «Пульса» в папке пользователя не выйдет).
'use strict';
const { app } = require('electron');
const fs = require('fs');
const path = require('path');
const T = require('./updsign');

const BUNDLED = (() => { try { return require('./package.json').version; } catch { return '0.0.0'; } })();
function newer(a, b) {
  const pa = String(a).split(/[.-]/).map((x) => parseInt(x, 10) || 0), pb = String(b).split(/[.-]/).map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d > 0; }
  return false;
}
const OTA = path.join(app.getPath('userData'), 'ota');
const STATE = path.join(OTA, 'state.json');
const read = () => { try { return JSON.parse(fs.readFileSync(STATE, 'utf8')) || {}; } catch { return {}; } };
const write = (s) => { try { fs.mkdirSync(OTA, { recursive: true }); fs.writeFileSync(STATE, JSON.stringify(s)); } catch {} };

// папка версии совпадает с подписанным пакетом: подпись верна, сумма пакета верна, файлы — те же байты, лишних нет
function trusted(dir, v) {
  try {
    const meta = JSON.parse(fs.readFileSync(path.join(dir, T.META), 'utf8'));
    if (!meta || meta.version !== v || !T.verifyPkg(meta)) return false;
    const buf = fs.readFileSync(path.join(dir, T.PKG));
    if (buf.length !== meta.size || T.sha256(buf) !== String(meta.sha256).toLowerCase()) return false;
    const want = new Map(T.readZip(buf).map((f) => [f.name.split(path.sep).join('/'), f.data]));
    let n = 0;
    const walk = (d, rel) => {
      for (const e of fs.readdirSync(d, { withFileTypes: true })) {
        const r = rel ? rel + '/' + e.name : e.name;
        if ((!rel && (e.name === T.META || e.name === T.PKG)) || e.name === '.DS_Store') continue;
        if (e.isDirectory()) { walk(path.join(d, e.name), r); continue; }
        const w = want.get(r);
        if (!w || !e.isFile() || !w.equals(fs.readFileSync(path.join(d, e.name)))) throw new Error('файл ' + r);
        n++;
      }
    };
    walk(dir, '');
    return n === want.size;
  } catch { return false; }
}
function note(t) { try { fs.mkdirSync(path.join(app.getPath('userData'), 'logs'), { recursive: true }); fs.appendFileSync(path.join(app.getPath('userData'), 'logs', 'pulse.log'), new Date().toISOString() + ' загрузчик: ' + t + '\n'); } catch {} }

// подходит ли версия из ota/: новее встроенной, движок подходит, файлы на месте и подписаны, не помечена сломанной
function usable(s, v) {
  if (!v || !/^[\d.]+$/.test(v) || !newer(v, BUNDLED) || (s.bad || []).includes(v)) return false;
  const dir = path.join(OTA, v);
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8'));
    if (pkg.version !== v) return false;
    if (pkg.minElectron && newer(pkg.minElectron, process.versions.electron)) return false;
    if (!fs.existsSync(path.join(dir, 'main.js')) || !fs.existsSync(path.join(dir, 'dist', 'index.html'))) return false;
  } catch { return false; }
  if (!trusted(dir, v)) { note('версия ' + v + ' в ota/ не прошла проверку подписи — запускаю встроенную'); return false; }
  return true;
}

function pick() {
  const s = read();
  // встроенная версия уже не старее скачанных (поставили новую Pulse.app) — старые обновления не нужны
  if (s.current && !newer(s.current, BUNDLED)) { cleanup(s, ''); return null; }
  let v = s.current;
  if (v && (s.tries || 0) >= 2) {   // два запуска подряд без окна — эта версия сломана
    s.bad = [...new Set([...(s.bad || []), v])].slice(-10);
    v = usable(s, s.previous) ? s.previous : '';
    s.current = v; s.previous = ''; s.tries = 0;
  }
  if (!usable(s, v)) { if (s.current) { s.current = ''; s.tries = 0; write(s); } return null; }
  s.tries = (s.tries || 0) + 1; write(s);
  return v;
}
// удалить папки версий, кроме нужных
function cleanup(s, keep) {
  try { for (const d of fs.readdirSync(OTA)) if (/^[\d.]+$/.test(d) && d !== keep && !(keep && d === s.previous)) fs.rmSync(path.join(OTA, d), { recursive: true, force: true }); } catch {}
  if (!keep) { s.current = ''; s.previous = ''; s.tries = 0; write(s); }
}

const v = pick();
global.__pulseBoot = {
  bundled: BUNDLED, version: v || BUNDLED, ota: OTA, fromOta: !!v, v: 2,   // v2 — проверяет подпись при запуске
  // программа показала окно — версия рабочая
  ok() { const s = read(); if (s.tries) { s.tries = 0; write(s); } },
};
if (v) {
  app.getVersion = () => v;
  try { require(path.join(OTA, v, 'main.js')); }
  catch (e) {
    // версия из ota/ не запустилась сразу — помечаем и запускаем предыдущую (или встроенную)
    const s = read(); s.bad = [...new Set([...(s.bad || []), v])].slice(-10); s.current = usable(s, s.previous) ? s.previous : ''; s.previous = ''; s.tries = 0; write(s);
    try { fs.mkdirSync(path.join(app.getPath('userData'), 'logs'), { recursive: true }); fs.appendFileSync(path.join(app.getPath('userData'), 'logs', 'pulse.log'), new Date().toISOString() + ' загрузчик: версия ' + v + ' не запустилась: ' + (e && e.stack || e) + '\n'); } catch {}
    app.relaunch(); app.exit(0);
  }
} else {
  require('./main.js');
}
