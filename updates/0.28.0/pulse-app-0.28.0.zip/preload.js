// Мост между окном и главным процессом: окно видит только эти функции (без доступа к файлам и системе).
'use strict';
const { contextBridge, ipcRenderer, webUtils } = require('electron');
const call = (m) => (...a) => ipcRenderer.invoke('ym:' + m, ...a);
contextBridge.exposeInMainWorld('pulse', {
  account: call('account'), search: call('search'), chart: call('chart'), artist: call('artist'), artistInfo: call('artistInfo'),
  album: call('album'), wave: call('wave'), waveFeedback: call('waveFeedback'), stream: call('stream'), lyrics: call('lyrics'), landing: call('landing'), playlist: call('playlist'), likes: call('likes'), tracksById: call('tracksById'), likeSet: call('likeSet'),
  openExternal: (u) => ipcRenderer.invoke('open-external', u),
  // токен Яндекс Музыки — из зашифрованного хранилища Windows (читается один раз при запуске), сохраняется туда же
  initialToken: ipcRenderer.sendSync('secret:get'),
  saveToken: (t) => ipcRenderer.invoke('secret:set', t),
  openDevTools: () => ipcRenderer.invoke('dev:devtools'),
  perf: () => ipcRenderer.invoke('perf'),
  perfSlow: (v) => ipcRenderer.invoke('perf:slow', !!v),
  perfUnsafe: () => ipcRenderer.invoke('perf:unsafe'),
  relaunch: () => ipcRenderer.invoke('perf:relaunch'),
  audioCors: (u) => ipcRenderer.invoke('audio:cors', u),
  socialGet: () => ipcRenderer.invoke('social:get'),
  socialSet: (p) => ipcRenderer.invoke('social:set', p),
  yaFmt: (u) => ipcRenderer.invoke('ya:fmt', String(u || '')),   // частота и разрядность играющего трека Яндекса
  online: () => ipcRenderer.invoke('online:get'),
  fullscreen: (v) => ipcRenderer.invoke('win:fs', v),
  onFullscreen: (cb) => { const h = (_e, v) => cb(!!v); ipcRenderer.on('win:fs', h); return () => ipcRenderer.removeListener('win:fs', h); },
  onPower: (cb) => ipcRenderer.on('power', (_e, v) => cb(!!v)),
  // обновления: проверить, поставить (с прогрессом), перезапустить
  update: {
    check: () => ipcRenderer.invoke('upd:check'),
    install: () => ipcRenderer.invoke('upd:install'),
    restart: () => ipcRenderer.invoke('upd:restart'),
    prepare: () => ipcRenderer.invoke('upd:prepare'),
    ready: () => ipcRenderer.invoke('upd:ready'),
    onProgress: (cb) => { const h = (_e, v) => cb(v); ipcRenderer.on('upd:progress', h); return () => ipcRenderer.removeListener('upd:progress', h); },
  },
  // своя музыка с компьютера (см. local.js): окно получает только список и адреса pulsefile://, не сами пути к файлам
  local: {
    list: () => ipcRenderer.invoke('local:list'),
    pick: () => ipcRenderer.invoke('local:pick'),
    // перетащенные в окно папки и файлы: путь узнаём здесь, окну он не нужен
    drop: (fileList) => { const ps = []; for (const f of Array.from(fileList || [])) { try { const p = webUtils.getPathForFile(f); if (p) ps.push(p); } catch {} } return ipcRenderer.invoke('local:add', ps); },
    remove: (root) => ipcRenderer.invoke('local:remove', root),
    rescan: () => ipcRenderer.invoke('local:rescan'),
    hide: (ids) => ipcRenderer.invoke('local:hide', ids),
    unhide: () => ipcRenderer.invoke('local:unhide'),
    reveal: (id) => ipcRenderer.invoke('local:reveal', id),
    onChange: (cb) => { const h = () => cb(); ipcRenderer.on('local:changed', h); return () => ipcRenderer.removeListener('local:changed', h); },
    onProgress: (cb) => { const h = (_e, v) => cb(v); ipcRenderer.on('local:progress', h); return () => ipcRenderer.removeListener('local:progress', h); },
  },
  // запись аудио-CD (см. burn.js): окно готовит звук в формате CD, программа пишет его встроенными средствами системы
  cd: {
    drives: () => ipcRenderer.invoke('cd:drives'),
    begin: (n) => ipcRenderer.invoke('cd:begin', n),
    put: (id, i, data) => ipcRenderer.invoke('cd:put', id, i, data),
    burn: (id, o) => ipcRenderer.invoke('cd:burn', id, o),
    eject: (d) => ipcRenderer.invoke('cd:eject', d),
    cancel: () => ipcRenderer.invoke('cd:cancel'),
    onProgress: (cb) => { const h = (_e, v) => cb(v); ipcRenderer.on('cd:progress', h); return () => ipcRenderer.removeListener('cd:progress', h); },
  },
  version: () => ipcRenderer.invoke('app:version'),
  devUnlock: (pw) => ipcRenderer.invoke('dev:unlock', pw),
  platform: process.platform,
});
