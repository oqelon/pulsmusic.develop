// «Пульс» в Диспетчере задач Windows.
//
// Программа — это Electron: установщик просто переименовывает electron.exe в Pulse.exe, а внутри файла остаются
// «паспорт» и значок Electron. Диспетчер задач берёт имя группы процессов из описания файла, поэтому там было
// «Electron». Здесь «Пульс» один раз сам переписывает описание (Пульс) и значок в копии своего Pulse.exe:
//   1) поток-помощник (exebrand-worker.js, внутри resedit) делает Pulse.new.exe — меняется только раздел ресурсов,
//      код программы не трогается;
//   2) копия проходит самопроверку (--pulse-selftest — та же, что после установки);
//   3) файлы меняются местами: работающий Pulse.exe переименовывается в Pulse.old.exe (Windows это позволяет),
//      копия становится Pulse.exe. Со следующего запуска все процессы — одна задача «Пульс» со своим значком.
// Не получилось — ничего не меняется (после двух неудач больше не пытаемся). Pulse.old.exe удаляется при следующем запуске.
'use strict';
const { app } = require('electron');
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');

const BRAND_V = 1;   // поднять, если поменяются название или значок — программа перепишет файл ещё раз

function start(log) {
  if (process.platform !== 'win32' || !app.isPackaged) return;
  const exe = process.execPath; const dir = path.dirname(exe);
  if (path.basename(exe).toLowerCase() !== 'pulse.exe') return;
  const old = path.join(dir, 'Pulse.old.exe'), neu = path.join(dir, 'Pulse.new.exe');
  for (const f of [old, neu]) fs.promises.rm(f, { force: true }).catch(() => {});
  const stFile = path.join(app.getPath('userData'), 'exebrand.json');
  let st = {}; try { st = JSON.parse(fs.readFileSync(stFile, 'utf8')) || {}; } catch {}
  let cur; try { cur = fs.statSync(exe); } catch { return; }
  if (st.v === BRAND_V && st.size === cur.size && st.mtime === Math.round(cur.mtimeMs)) return;   // уже «Пульс»
  if ((st.fails || 0) >= 2 && st.failV === BRAND_V) return;
  const save = (o) => { try { fs.writeFileSync(stFile, JSON.stringify(o)); } catch {} };
  const fail = (why) => { log('значок и название в Диспетчере задач: не получилось —', why); fs.promises.rm(neu, { force: true }).catch(() => {}); save({ ...st, fails: (st.failV === BRAND_V ? st.fails || 0 : 0) + 1, failV: BRAND_V }); };
  // через полминуты после запуска, чтобы не мешать открытию окна; работа идёт в отдельном потоке
  setTimeout(() => {
    let w; try {
      const { Worker } = require('worker_threads');
      w = new Worker(path.join(__dirname, 'exebrand-worker.js'), { workerData: { exe, out: neu, ico: path.join(__dirname, 'build', 'icon.ico'), version: app.getVersion() } });
    } catch (e) { return fail(e && e.message); }
    w.once('error', (e) => fail(e && e.message));
    w.once('message', (m) => {
      if (!m || !m.ok) return fail(m && m.error);
      const out = path.join(app.getPath('temp'), 'pulse-brand-test-' + process.pid + '.json');
      execFile(neu, ['--pulse-selftest', out], { timeout: 60000, windowsHide: true }, () => {
        let r = {}; try { r = JSON.parse(fs.readFileSync(out, 'utf8')); } catch {}
        fs.promises.rm(out, { force: true }).catch(() => {});
        if (!r.ok) return fail('самопроверка: ' + (r.why || 'нет ответа'));
        try { fs.renameSync(exe, old); } catch (e) { return fail('не переименовать Pulse.exe: ' + e.message); }
        try { fs.renameSync(neu, exe); } catch (e) { try { fs.renameSync(old, exe); } catch {} return fail('не поставить новый Pulse.exe: ' + e.message); }
        let n; try { n = fs.statSync(exe); } catch {}
        save({ v: BRAND_V, size: n && n.size, mtime: n && Math.round(n.mtimeMs) });
        log('значок и название в Диспетчере задач: готово, со следующего запуска — «Пульс»');
      });
    });
  }, 30000).unref();
}
module.exports = { start };
