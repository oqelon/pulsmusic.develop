// «Сейчас онлайн»: раз в 5 минут программа отмечается на счётчике (online-server/ — Cloudflare Worker).
// Отправляется только случайный номер этой копии «Пульса» (создаётся один раз, хранится в %APPDATA%\Pulse\online-id)
// и слово 'pc'. Ни токена, ни логина, ни треков. Адрес счётчика берётся из latest.json обновлений (поле online),
// поэтому его можно подключить или поменять без новой версии программы. Нет адреса — ничего не отправляется.
'use strict';
const { app } = require('electron');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { FEED } = require('./updater');

let url = '', id = '', timer = null, feedT = null;
const ok = (u) => { try { const x = new URL(String(u)); return x.protocol === 'https:' && x.hostname.endsWith('.workers.dev') && !x.search ? x.origin : ''; } catch { return ''; } };
function myId() {
  if (id) return id;
  const f = path.join(app.getPath('userData'), 'online-id');
  try { const v = fs.readFileSync(f, 'utf8').trim(); if (/^[a-f0-9]{32}$/.test(v)) return (id = v); } catch {}
  id = crypto.randomBytes(16).toString('hex'); try { fs.writeFileSync(f, id); } catch {}
  return id;
}
async function readFeed() {
  if (process.env.PULSE_ONLINE) return ok(process.env.PULSE_ONLINE);
  try {
    const r = await fetch(FEED + '?t=' + Date.now(), { headers: { 'User-Agent': 'PulseDesktop/' + app.getVersion() }, redirect: 'follow', signal: AbortSignal.timeout(15000) });
    if (!r.ok) return url; const m = await r.json(); return ok(m && m.online);
  } catch { return url; }
}
async function ping() {
  if (!url) return;
  try { await fetch(url + '/ping', { method: 'POST', headers: { 'content-type': 'application/json', 'User-Agent': 'PulseDesktop/' + app.getVersion() }, body: JSON.stringify({ id: myId(), p: 'pc' }), signal: AbortSignal.timeout(10000) }); } catch {}
}
function start() {
  // считаем только установленную программу (запуски для проверки не в счёт), кроме теста с PULSE_ONLINE
  if (!app.isPackaged && !process.env.PULSE_ONLINE) return;
  const refresh = async () => { const u = await readFeed(); if (u !== url) { url = u; if (url) ping(); } };
  setTimeout(refresh, 15000);
  feedT = setInterval(refresh, 6 * 3600 * 1000);
  timer = setInterval(ping, 5 * 60 * 1000);
}
// для режима разработчика
async function count() {
  if (!url) url = await readFeed();
  if (!url) return { ok: false, none: true };
  try {
    const r = await fetch(url + '/online?t=' + Date.now(), { signal: AbortSignal.timeout(10000) });
    if (!r.ok) return { ok: false, error: 'Счётчик ответил ' + r.status };
    const v = await r.json(); return { ok: true, v: { total: +v.total || 0, pc: +v.pc || 0, mobile: +v.mobile || 0, at: +v.at || Date.now() } };
  } catch (e) { return { ok: false, error: 'Счётчик недоступен' }; }
}
// адрес нашего сервера (для общей базы времени слов живого текста)
let baseP = null;
async function base() {
  if (url) return url;
  if (!baseP) baseP = readFeed().then((u) => { if (u) url = u; baseP = null; return u; });
  return baseP;
}
module.exports = { start, count, base };
