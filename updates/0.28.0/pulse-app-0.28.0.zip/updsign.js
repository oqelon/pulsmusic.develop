// Подпись обновлений «Пульса» (Ed25519).
//
// Каждое обновление подписывается закрытым ключом, который хранится только у разработчика (не в репозитории и не на
// GitHub). Здесь — только открытый ключ: им программа проверяет, что пакет выпустил автор «Пульса». Без верной подписи
// обновление не скачивается и не запускается — даже если кто-то получит доступ к репозиторию или подменит файл на CDN.
//
// Что подписано:
//   пакет программы (latest.json): «PULSE-UPDATE-V1 \n версия \n sha256 пакета \n размер \n minElectron»
//   сборка для Mac (mac.json):     «PULSE-MAC-V1 \n версия \n arm64|x64 \n sha256 архива \n размер»
// Сам пакет защищён своей SHA-256 (она внутри подписи), версия — от подмены на старую.
'use strict';
const crypto = require('crypto');
const zlib = require('zlib');
const path = require('path');

const KEY = '0YOwoaasY+1McD/zRxs0yNs3eywt/TCfmjYyMDkCuIs=';
const SPKI = Buffer.from('302a300506032b6570032100', 'hex');
// проверка на тестовом сервере (mac/test, PULSE_UPDATE_FEED) — своим тестовым ключом; в обычной работе ключ один
const keyB64 = () => (process.env.PULSE_UPDATE_FEED && process.env.PULSE_UPDATE_PUBKEY) || KEY;
let cache = null;
function pub() {
  const b = keyB64();
  if (!cache || cache.b !== b) cache = { b, k: crypto.createPublicKey({ key: Buffer.concat([SPKI, Buffer.from(b, 'base64')]), format: 'der', type: 'spki' }) };
  return cache.k;
}
const hex = (s) => String(s || '').toLowerCase();
const pkgMsg = (m) => ['PULSE-UPDATE-V1', m.version, hex(m.sha256), String(Number(m.size) || 0), m.minElectron || ''].join('\n');
const macMsg = (v, arch, a) => ['PULSE-MAC-V1', v, arch, hex(a.sha256), String(Number(a.size) || 0)].join('\n');
function good(msg, sig) {
  try {
    const s = Buffer.from(String(sig || ''), 'base64');
    return s.length === 64 && crypto.verify(null, Buffer.from(msg, 'utf8'), pub(), s);
  } catch { return false; }
}
const verifyPkg = (m) => !!(m && m.version && /^[0-9a-f]{64}$/i.test(String(m.sha256 || '')) && m.size > 0 && good(pkgMsg(m), m.sig));
const verifyMac = (v, arch, a) => !!(a && /^[0-9a-f]{64}$/i.test(String(a.sha256 || '')) && a.size > 0 && good(macMsg(v, arch, a), a.sig));
const sha256 = (buf) => crypto.createHash('sha256').update(buf).digest('hex');

// ---------- распаковка zip без сторонних библиотек ----------
function readZip(buf) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('пакет обновления повреждён (не zip)');
  const n = buf.readUInt16LE(eocd + 10); let p = buf.readUInt32LE(eocd + 16);
  const out = [];
  for (let k = 0; k < n; k++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('пакет обновления повреждён');
    const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24);
    const nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nl);
    p += 46 + nl + xl + cl;
    if (name.endsWith('/')) continue;
    if (buf.readUInt32LE(lo) !== 0x04034b50) throw new Error('пакет обновления повреждён');
    const start = lo + 30 + buf.readUInt16LE(lo + 26) + buf.readUInt16LE(lo + 28);
    const raw = buf.subarray(start, start + csize);
    const data = method === 0 ? Buffer.from(raw) : method === 8 ? zlib.inflateRawSync(raw) : null;
    if (!data) throw new Error('пакет обновления сжат неизвестным способом');
    if (data.length !== usize) throw new Error('пакет обновления повреждён (размер)');
    // только безопасные пути внутри папки программы
    const rel = path.normalize(name).replace(/^([/\\])+/, '');
    if (rel.startsWith('..') || path.isAbsolute(rel)) continue;
    out.push({ name: rel, data });
  }
  return out;
}

// рядом с версией в ota/ лежат её пакет и подпись — по ним загрузчик Mac перепроверяет папку при каждом запуске
const META = '.pulse-sig.json', PKG = '.pulse-pkg.zip';

module.exports = { verifyPkg, verifyMac, pkgMsg, macMsg, sha256, readZip, META, PKG };
