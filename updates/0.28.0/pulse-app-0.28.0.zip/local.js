// Своя музыка с компьютера (главный процесс): FLAC, MP3, M4A/M4B, OGG, Opus, WAV, WebM и альбомы одним файлом с CUE.
// Образы дисков: ISO (ISO 9660 и Joliet) — треки играют прямо из образа, ничего не распаковывая; копии аудио-CD
// BIN/IMG + CUE — «сырой» звук диска отдаётся окну как WAV с разметкой треков из CUE.
//
// • Музыка никуда не копируется: запоминаем только выбранные папки и то, что в них нашли
//   (%APPDATA%\Pulse\local-library.json). Обложки из файлов кладём в %APPDATA%\Pulse\local-covers.
// • Окно получает звук и обложки по адресам pulsefile://a/<id> и pulsefile://c/<id>. Отдаются только файлы,
//   которые нашлись в выбранных папках, — по такому адресу нельзя прочитать произвольный файл с диска.
// • Теги читаем сами (без сторонних модулей): FLAC — STREAMINFO, Vorbis-комментарии, картинка, встроенный CUE;
//   MP3 — ID3v2 (2.2–2.4) и ID3v1, длительность по заголовку Xing/VBRI или по битрейту; WAV — длительность.
//   CUE — в UTF-8 или Windows-1251 (так сохраняют большинство русских рипов).
// • Папки пересматриваются при запуске и когда в них что-то меняется (новые файлы появятся сами).
'use strict';
const { app, protocol, ipcMain, dialog, shell, BrowserWindow, nativeImage } = require('electron');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');

const AUDIO = { '.flac': 'FLAC', '.mp3': 'MP3', '.m4a': 'AAC', '.m4b': 'AAC', '.aac': 'AAC', '.ogg': 'OGG', '.oga': 'OGG', '.opus': 'OPUS', '.wav': 'WAV', '.webm': 'WEBM', '.weba': 'WEBM' };
const MIME = { '.flac': 'audio/flac', '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4', '.m4b': 'audio/mp4', '.aac': 'audio/aac', '.ogg': 'audio/ogg', '.oga': 'audio/ogg', '.opus': 'audio/ogg', '.wav': 'audio/wav', '.webm': 'audio/webm', '.weba': 'audio/webm' };
const DISC = /\.(iso|bin|img)$/i;   // образы дисков (BIN/IMG — только вместе с CUE)
const VSEP = '::';                  // «путь к образу::/путь внутри» — виртуальный файл
const IMG = /\.(jpe?g|png|webp|bmp|gif)$/i;   // любые картинки рядом с музыкой — из них выбирается обложка (см. pickCover)
const PV = 4;   // версия разбора тегов: выросла — файлы перечитываются (например, научились новым обложкам)
const MAX_FILES = 60000, MAX_DEPTH = 14;

// схема регистрируется до запуска приложения
// pulseya — звук Яндекса через программу (см. yastream.js)
protocol.registerSchemesAsPrivileged(['pulsefile', 'pulseya'].map((scheme) => ({ scheme, privileges: { standard: true, secure: true, stream: true, supportFetchAPI: true, corsEnabled: true } })));

let log = () => {};
const libFile = () => path.join(app.getPath('userData'), 'local-library.json');
const covDir = () => path.join(app.getPath('userData'), 'local-covers');
const sha = (s) => crypto.createHash('sha1').update(s).digest('hex');
const fid = (p) => sha(path.resolve(p).toLowerCase()).slice(0, 16);

// lib: roots — выбранные папки/файлы; cache — путь → { m, s, meta } (чтобы не читать заново неизменившиеся файлы)
let lib = { v: 1, roots: [], cache: {}, thumbs: {}, hidden: [] };   // hidden — убранные из «Пульса» файлы (сами файлы на месте)
let files = new Map();   // id файла → путь (только найденное в выбранных папках)
let covers = new Map();  // id обложки → путь
let tracks = [];
let scanning = null;
let vfs = new Map();     // виртуальный путь → { src, off, size, wav } (файл внутри ISO или звук аудио-CD из BIN)
let stamps = new Map();   // путь → дата и размер при последнем просмотре (чтобы не пересматривать папки зря)     // { done, total, name }
function load() {
  try {
    const v = JSON.parse(fs.readFileSync(libFile(), 'utf8'));
    if (v && Array.isArray(v.roots)) { lib = { v: 1, roots: v.roots, cache: v.cache || {}, thumbs: v.thumbs || {}, hidden: Array.isArray(v.hidden) ? v.hidden : [], isoc: v.isoc || {} }; tracks = Array.isArray(v.tracks) ? v.tracks : []; files = new Map(Object.entries(v.files || {})); covers = new Map(Object.entries(v.covers || {})); vfs = new Map(Object.entries(v.vfs || {})); }
  } catch {}
}
let saveT = null;
function save() { clearTimeout(saveT); saveT = setTimeout(() => { fsp.writeFile(libFile(), JSON.stringify({ ...lib, tracks, files: Object.fromEntries(files), covers: Object.fromEntries(covers), vfs: Object.fromEntries(vfs) })).catch((e) => log('своя музыка: не сохранил', e && e.message)); }, 400); }
function send(ch, v) { for (const w of BrowserWindow.getAllWindows()) if (!w.isDestroyed()) w.webContents.send(ch, v); }

// ---------- чтение файла кусками ----------
async function readAt(fh, pos, len) { const b = Buffer.alloc(len); const { bytesRead } = await fh.read(b, 0, len, pos); return b.subarray(0, bytesRead); }
// заголовок WAV для «сырого» звука аудио-CD: 44,1 кГц, 16 бит, стерео
function wavHead(n) { const h = Buffer.alloc(44); h.write('RIFF', 0, 'latin1'); h.writeUInt32LE(36 + n, 4); h.write('WAVEfmt ', 8, 'latin1'); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(2, 22); h.writeUInt32LE(44100, 24); h.writeUInt32LE(176400, 28); h.writeUInt16LE(4, 32); h.writeUInt16LE(16, 34); h.write('data', 36, 'latin1'); h.writeUInt32LE(n, 40); return h; }
// открыть файл на чтение — обычный или виртуальный (кусок образа). Возвращает { read(buf, o, len, pos), size, close() }
async function openR(p) {
  const v = vfs.get(p);
  if (!v) { const fh = await fsp.open(p, 'r'); const st = await fh.stat(); return { size: st.size, read: (b, o, l, pos) => fh.read(b, o, l, pos), close: () => fh.close() }; }
  const fh = await fsp.open(v.src, 'r'); const H = v.wav ? wavHead(v.size) : null; const hl = H ? 44 : 0;
  return { size: v.size + hl, close: () => fh.close(),
    read: async (b, o, l, pos) => {
      let done = 0;
      if (H && pos < hl) { const n = Math.min(l, hl - pos); H.copy(b, o, pos, pos + n); done = n; pos += n; }
      const rest = Math.min(l - done, v.size - (pos - hl)); if (rest > 0) { const { bytesRead } = await fh.read(b, o + done, rest, v.off + pos - hl); done += bytesRead; }
      return { bytesRead: done };
    } };
}
async function readAll(p) { if (!vfs.has(p)) return fsp.readFile(p); const fh = await openR(p); try { const b = Buffer.alloc(fh.size); await fh.read(b, 0, fh.size, 0); return b; } finally { await fh.close().catch(() => {}); } }
const realOf = (p) => (vfs.has(p) ? vfs.get(p).src : p);
const extOf = (p) => (vfs.has(p) && vfs.get(p).wav ? '.wav' : path.extname(p).toLowerCase());

// ---------- ISO 9660 / Joliet: список файлов образа без распаковки ----------
// Сектор 2048 байт. Описатели тома — с 16-го сектора: 1 — основной, 2 с «%/@ %/C %/E» — Joliet (имена в UTF-16).
// Образ SACD (в 510-м секторе «SACDMTOC») и образы только с UDF пока не читаем — пишем в журнал.
async function isoList(p) {
  const fh = await fsp.open(p, 'r');
  try {
    const st = await fh.stat(); let root = null, joliet = false;
    for (let s = 16; s < 64; s++) {
      const d = await readAt(fh, s * 2048, 2048); if (d.length < 2048 || d.toString('latin1', 1, 6) !== 'CD001') break;
      const t = d[0]; if (t === 255) break;
      if (t === 1 && !root) root = d.subarray(156, 190);
      if (t === 2 && d[88] === 0x25 && d[89] === 0x2f && [0x40, 0x43, 0x45].includes(d[90])) { root = d.subarray(156, 190); joliet = true; }
    }
    if (!root) {
      const sa = await readAt(fh, 510 * 2048, 8);
      log('своя музыка: образ не прочитан —', path.basename(p), sa.toString('latin1') === 'SACDMTOC' ? '(SACD пока не поддерживается)' : '(нет ISO 9660)');
      return { sacd: sa.toString('latin1') === 'SACDMTOC', items: [] };
    }
    const items = []; let guard = 0;
    const name = (b) => (joliet ? new TextDecoder('utf-16be').decode(b) : b.toString('latin1')).replace(/;\d+$/, '').replace(/\.$/, '');
    const dir = async (lba, len, rel, depth) => {
      if (depth > 12 || guard > 20000) return;
      const d = await readAt(fh, lba * 2048, Math.min(len, 8 * 1024 * 1024)); let o = 0;
      while (o < d.length && guard++ < 20000) {
        const rl = d[o]; if (!rl) { o = (Math.floor(o / 2048) + 1) * 2048; continue; }
        const ext = d.readUInt32LE(o + 2), sz = d.readUInt32LE(o + 10), fl = d[o + 25], nl = d[o + 32]; const nb = d.subarray(o + 33, o + 33 + nl);
        if (!(nl === 1 && (nb[0] === 0 || nb[0] === 1))) {
          const n = name(nb); const r2 = rel + '/' + n;
          if (fl & 2) await dir(ext, sz, r2, depth + 1);
          else if (ext * 2048 + sz <= st.size) items.push({ rel: r2, off: ext * 2048, size: sz });
        }
        o += rl;
      }
    };
    await dir(root.readUInt32LE(2), root.readUInt32LE(10), '', 0);
    return { items };
  } finally { await fh.close().catch(() => {}); }
}
const dec1251 = new TextDecoder('windows-1251');
const decUtf8 = new TextDecoder('utf-8', { fatal: true });
function textAuto(b) {
  if (b[0] === 0xef && b[1] === 0xbb && b[2] === 0xbf) return b.subarray(3).toString('utf8');
  if (b[0] === 0xff && b[1] === 0xfe) return new TextDecoder('utf-16le').decode(b.subarray(2));
  try { return decUtf8.decode(b); } catch { return dec1251.decode(b); }
}
const clean = (s) => String(s || '').replace(/\0+$/g, '').replace(/[\u0000-\u001f]/g, ' ').trim();

// ---------- FLAC ----------
async function flacMeta(fh, size) {
  let pos = 0; let h = await readAt(fh, 0, 10);
  if (h.toString('latin1', 0, 3) === 'ID3') pos = 10 + syncsafe(h, 6);
  h = await readAt(fh, pos, 4); if (h.toString('latin1') !== 'fLaC') return null;
  pos += 4; const m = { codec: 'FLAC', tags: {} }; let last = false; let guard = 0;
  while (!last && guard++ < 64 && pos < size) {
    const bh = await readAt(fh, pos, 4); if (bh.length < 4) break;
    last = !!(bh[0] & 0x80); const type = bh[0] & 0x7f; const len = bh.readUIntBE(1, 3); pos += 4;
    if (type === 0 && len >= 18) {
      const b = await readAt(fh, pos, 18);
      m.sr = (b[10] << 12) | (b[11] << 4) | (b[12] >> 4); m.ch = ((b[12] >> 1) & 7) + 1; m.bits = (((b[12] & 1) << 4) | (b[13] >> 4)) + 1;
      const total = (b[13] & 0x0f) * 4294967296 + b.readUInt32BE(14); if (m.sr) m.dur = total / m.sr;
    } else if (type === 4 && len < 32 * 1024 * 1024) {
      vorbisComments(await readAt(fh, pos, len), 0, m);
    } else if (type === 6 && len < 32 * 1024 * 1024 && !(m.pic && m.pic.type === 3)) {
      const pic = picBlock(await readAt(fh, pos, len)); if (pic && better(m.pic, pic.type)) m.pic = pic;
    }
    pos += len;
  }
  if (m.dur) m.kbps = Math.round((size * 8) / m.dur / 1000);
  return m;
}
// картинка: сначала лицевая обложка (тип 3), иначе любая; блок PICTURE одинаков во FLAC и в Ogg (METADATA_BLOCK_PICTURE)
// насколько картинка из файла похожа на лицевую обложку (меньше — лучше): 3 — «лицевая», 0 — «другая» (так пишут
// многие программы); 4 — задник, 5 — вкладыш, 6 — диск, 1/2 — значки файла
const embRank = (t) => (t === 3 ? 0 : t === 0 ? 0.5 : t === 4 || t === 5 || t === 6 ? 7 : t === 1 || t === 2 ? 8 : 2.5);
const better = (cur, type) => !cur || embRank(type) < embRank(cur.type);
function picBlock(b) {
  try {
    let o = 0; const type = b.readUInt32BE(o); o += 4; const ml = b.readUInt32BE(o); o += 4; const mime = b.toString('latin1', o, o + ml); o += ml;
    const dl = b.readUInt32BE(o); o += 4 + dl + 16; const n = b.readUInt32BE(o); o += 4;
    return n > 100 && o + n <= b.length ? { type, mime, data: b.subarray(o, o + n) } : null;
  } catch { return null; }
}
// Vorbis-комментарии (FLAC, Ogg Vorbis, Opus): «КЛЮЧ=значение»; картинка — в METADATA_BLOCK_PICTURE (base64)
function vorbisComments(b, o, m) {
  try {
    const vl = b.readUInt32LE(o); o += 4 + vl; const n = b.readUInt32LE(o); o += 4;
    for (let k = 0; k < n && o + 4 <= b.length; k++) {
      const l = b.readUInt32LE(o); o += 4; const e = b.indexOf(0x3d, o); if (e < 0 || e > o + l) { o += l; continue; }
      const key = b.toString('latin1', o, e).toUpperCase();
      if (key === 'METADATA_BLOCK_PICTURE' || key === 'COVERART') {
        const pic = key === 'COVERART' ? { type: 3, mime: 'image/jpeg', data: Buffer.from(b.toString('latin1', e + 1, o + l), 'base64') } : picBlock(Buffer.from(b.toString('latin1', e + 1, o + l), 'base64'));
        if (pic && pic.data.length > 100 && better(m.pic, pic.type)) m.pic = pic;
      } else if (!(key in m.tags)) m.tags[key] = b.toString('utf8', e + 1, o + l);
      o += l;
    }
  } catch {}
}
const syncsafe = (b, o) => ((b[o] & 0x7f) << 21) | ((b[o + 1] & 0x7f) << 14) | ((b[o + 2] & 0x7f) << 7) | (b[o + 3] & 0x7f);

// ---------- MP3 ----------
function id3text(b, enc) {
  if (enc === 1) { const le = !(b[0] === 0xfe && b[1] === 0xff); const s = new TextDecoder(le ? 'utf-16le' : 'utf-16be').decode(b[0] === 0xff || b[0] === 0xfe ? b.subarray(2) : b); return clean(s.split('\0')[0]); }
  if (enc === 2) return clean(new TextDecoder('utf-16be').decode(b).split('\0')[0]);
  if (enc === 3) return clean(b.toString('utf8').split('\0')[0]);
  // «латиница» по стандарту, но русские файлы почти всегда записаны в Windows-1251
  return clean(dec1251.decode(b).split('\0')[0]);
}
const ID3MAP = { TIT2: 'TITLE', TT2: 'TITLE', TPE1: 'ARTIST', TP1: 'ARTIST', TPE2: 'ALBUMARTIST', TP2: 'ALBUMARTIST', TALB: 'ALBUM', TAL: 'ALBUM', TRCK: 'TRACKNUMBER', TRK: 'TRACKNUMBER', TPOS: 'DISCNUMBER', TPA: 'DISCNUMBER', TYER: 'DATE', TYE: 'DATE', TDRC: 'DATE', TCON: 'GENRE', TCO: 'GENRE' };
async function mp3Meta(fh, size) {
  const m = { codec: 'MP3', tags: {} }; let start = 0;
  const h = await readAt(fh, 0, 10);
  if (h.toString('latin1', 0, 3) === 'ID3') {
    const ver = h[3]; const tsize = syncsafe(h, 6); start = 10 + tsize + (h[5] & 0x10 ? 10 : 0);
    let b = await readAt(fh, 10, Math.min(tsize, 32 * 1024 * 1024)); let o = 0;
    const unsyncAll = !!(h[5] & 0x80);
    if (unsyncAll && ver < 4) b = deUnsync(b);   // 2.2/2.3: «рассинхронизация» на весь тег (так пишут старые программы)
    if (h[5] & 0x40 && ver >= 3) o += ver === 4 ? syncsafe(b, 0) : b.readUInt32BE(0) + 4;   // расширенный заголовок
    const small = ver === 2;
    while (o + (small ? 6 : 10) < b.length) {
      const id = b.toString('latin1', o, o + (small ? 3 : 4)); if (!/^[A-Z0-9]{3,4}$/.test(id)) break;
      const len = small ? b.readUIntBE(o + 3, 3) : ver === 4 ? syncsafe(b, o + 4) : b.readUInt32BE(o + 4);
      const fl = small ? 0 : b[o + 9];
      o += small ? 6 : 10; if (len <= 0 || o + len > b.length) break;
      let f = b.subarray(o, o + len); o += len;
      // флаги кадра: 2.4 — длина данных (0x01), рассинхронизация (0x02), сжатие (0x08), шифрование (0x04); 2.3 — сжатие (0x80), шифрование (0x40), группа (0x20)
      try {
        if (ver === 4) { if (fl & 0x04) continue; if (fl & 0x40) f = f.subarray(1); if (fl & 0x01) f = f.subarray(4); if ((fl & 0x02) || unsyncAll) f = deUnsync(f); if (fl & 0x08) f = zlib.inflateSync(f); }
        else if (ver === 3) { if (fl & 0x40) continue; if (fl & 0x80) f = zlib.inflateSync(f.subarray(4)); if (fl & 0x20) f = f.subarray(1); }
      } catch { continue; }
      if (!f.length) continue;
      if (ID3MAP[id]) { const v = id3text(f.subarray(1), f[0]); if (v && !(ID3MAP[id] in m.tags)) m.tags[ID3MAP[id]] = v; }
      else if ((id === 'APIC' || id === 'PIC') && !(m.pic && m.pic.type === 3)) {
        const enc = f[0]; let p = 1, mime;
        if (id === 'PIC') { mime = 'image/' + f.toString('latin1', 1, 4).toLowerCase().replace('jpg', 'jpeg'); p = 4; }
        else { const z = f.indexOf(0, 1); mime = f.toString('latin1', 1, z); p = z + 1; }
        const type = f[p]; p += 1;
        if (enc === 1 || enc === 2) { while (p + 1 < f.length && (f[p] || f[p + 1])) p += 2; p += 2; } else { const z = f.indexOf(0, p); p = z < 0 ? p : z + 1; }
        // описание бывает пустым, а картинка — сразу после; если «описание» съело начало картинки — ищем её начало сами
        let data = f.subarray(p); if (!imgExt(data)) { const at = findImg(f, 1); if (at > 0) data = f.subarray(at); }
        if (data.length > 100 && better(m.pic, type)) m.pic = { type, mime: mime || 'image/jpeg', data };
      }
    }
  }
  // ID3v1 в конце — если в ID3v2 ничего нет
  if (!m.tags.TITLE && size > 128) {
    const t = await readAt(fh, size - 128, 128);
    if (t.toString('latin1', 0, 3) === 'TAG') { const g = (a, b2) => clean(dec1251.decode(t.subarray(a, b2))); m.tags.TITLE = g(3, 33); m.tags.ARTIST = m.tags.ARTIST || g(33, 63); m.tags.ALBUM = m.tags.ALBUM || g(63, 93); m.tags.DATE = m.tags.DATE || g(93, 97); if (t[125] === 0 && t[126]) m.tags.TRACKNUMBER = String(t[126]); }
  }
  // длительность: первый кадр, заголовок Xing/Info/VBRI или битрейт
  const b = await readAt(fh, start, 64 * 1024);
  for (let i = 0; i + 4 < b.length; i++) {
    if (b[i] !== 0xff || (b[i + 1] & 0xe0) !== 0xe0) continue;
    const v = (b[i + 1] >> 3) & 3, layer = (b[i + 1] >> 1) & 3, bi = b[i + 2] >> 4, si = (b[i + 2] >> 2) & 3, mono = (b[i + 3] >> 6) === 3;
    if (v === 1 || layer !== 1 || bi === 0 || bi === 15 || si === 3) continue;
    const v1 = v === 3; const SR = v1 ? [44100, 48000, 32000] : v === 2 ? [22050, 24000, 16000] : [11025, 12000, 8000];
    const BR = v1 ? [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320] : [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160];
    m.sr = SR[si]; const spf = v1 ? 1152 : 576; m.ch = mono ? 1 : 2;
    const xo = i + 4 + (v1 ? (mono ? 17 : 32) : (mono ? 9 : 17)); const tag = b.toString('latin1', xo, xo + 4);
    if ((tag === 'Xing' || tag === 'Info') && b[xo + 7] & 1) { const frames = b.readUInt32BE(xo + 8); m.dur = (frames * spf) / m.sr; m.vbr = tag === 'Xing'; }
    else if (b.toString('latin1', i + 36, i + 40) === 'VBRI') { const frames = b.readUInt32BE(i + 36 + 14); m.dur = (frames * spf) / m.sr; m.vbr = true; }
    else { m.kbps = BR[bi]; m.dur = ((size - start - i) * 8) / (BR[bi] * 1000); }
    break;
  }
  if (m.dur && !m.kbps) m.kbps = Math.round(((size - start) * 8) / m.dur / 1000);
  return m;
}
function deUnsync(b) { const out = Buffer.alloc(b.length); let j = 0; for (let i = 0; i < b.length; i++) { out[j++] = b[i]; if (b[i] === 0xff && b[i + 1] === 0x00) i++; } return out.subarray(0, j); }
// по первым байтам: что это за картинка
function imgExt(d) {
  if (!d || d.length < 12) return '';
  if (d[0] === 0xff && d[1] === 0xd8) return '.jpg';
  if (d[0] === 0x89 && d.toString('latin1', 1, 4) === 'PNG') return '.png';
  if (d.toString('latin1', 0, 4) === 'RIFF' && d.toString('latin1', 8, 12) === 'WEBP') return '.webp';
  if (d.toString('latin1', 0, 3) === 'GIF') return '.gif';
  if (d[0] === 0x42 && d[1] === 0x4d) return '.bmp';
  return '';
}
function findImg(b, from) { for (let i = from; i < Math.min(b.length - 4, from + 4096); i++) if ((b[i] === 0xff && b[i + 1] === 0xd8 && b[i + 2] === 0xff) || (b[i] === 0x89 && b[i + 1] === 0x50 && b[i + 2] === 0x4e)) return i; return -1; }

// ---------- Ogg (Vorbis, Opus): теги, обложка и длительность ----------
async function oggMeta(fh, size, ext) {
  const m = { codec: ext === '.opus' ? 'OPUS' : 'OGG', tags: {} }; let pos = 0, pkt = [], pkts = [], rate = 0, pre = 0, opus = false;
  const LIMIT = Math.min(size, 40 * 1024 * 1024);
  while (pos < LIMIT && pkts.length < 3) {
    const h = await readAt(fh, pos, 27 + 255); if (h.length < 27 || h.toString('latin1', 0, 4) !== 'OggS') break;
    const ns = h[26]; const seg = h.subarray(27, 27 + ns); let dpos = pos + 27 + ns; const total = seg.reduce((a, x) => a + x, 0);
    const data = await readAt(fh, dpos, total); let o = 0;
    for (let i = 0; i < ns; i++) { pkt.push(data.subarray(o, o + seg[i])); o += seg[i]; if (seg[i] < 255) { pkts.push(Buffer.concat(pkt)); pkt = []; if (pkts.length >= 3) break; } }
    pos = dpos + total;
  }
  for (const p of pkts) {
    if (p.toString('latin1', 0, 8) === 'OpusHead') { opus = true; m.codec = 'OPUS'; m.ch = p[9]; pre = p.readUInt16LE(10); rate = 48000; m.sr = p.readUInt32LE(12) || 48000; }
    else if (p[0] === 1 && p.toString('latin1', 1, 7) === 'vorbis') { m.ch = p[11]; rate = m.sr = p.readUInt32LE(12); m.codec = 'OGG'; }
    else if (p.toString('latin1', 0, 8) === 'OpusTags') vorbisComments(p, 8, m);
    else if (p[0] === 3 && p.toString('latin1', 1, 7) === 'vorbis') vorbisComments(p, 7, m);
  }
  // длительность — по позиции последней страницы
  if (rate) { const tail = await readAt(fh, Math.max(0, size - 65536), Math.min(size, 65536)); const at = tail.lastIndexOf('OggS'); if (at >= 0 && at + 14 <= tail.length) { const g = Number(tail.readBigUInt64LE(at + 6)); if (g > 0) m.dur = Math.max(0, g - (opus ? pre : 0)) / rate; } }
  if (m.dur) m.kbps = Math.round((size * 8) / m.dur / 1000);
  return m;
}
// ---------- M4A (AAC, ALAC): атомы moov → mvhd, stsd, udta/meta/ilst ----------
async function mp4Meta(fh, size) {
  const m = { codec: 'AAC', tags: {} }; let pos = 0, moov = null;
  while (pos + 8 <= size) {
    const h = await readAt(fh, pos, 16); if (h.length < 8) break; let len = h.readUInt32BE(0); const type = h.toString('latin1', 4, 8); let hl = 8;
    if (len === 1) { len = Number(h.readBigUInt64BE(8)); hl = 16; } else if (len === 0) len = size - pos;
    if (len < 8) break;
    if (type === 'moov') { if (len > 64 * 1024 * 1024) break; moov = await readAt(fh, pos + hl, len - hl); break; }
    pos += len;
  }
  if (!moov) return m;
  const kids = (b, from, to, cb) => { let o = from; while (o + 8 <= to) { let l = b.readUInt32BE(o); const t = b.toString('latin1', o + 4, o + 8); let hl = 8; if (l === 1) { l = Number(b.readBigUInt64BE(o + 8)); hl = 16; } else if (l === 0) l = to - o; if (l < 8 || o + l > to) break; cb(t, o + hl, o + l); o += l; } };
  const MAP = { '©nam': 'TITLE', '©ART': 'ARTIST', 'aART': 'ALBUMARTIST', '©alb': 'ALBUM', '©day': 'DATE', '©gen': 'GENRE', '©cmt': 'COMMENT' };
  const walkBox = (from, to) => kids(moov, from, to, (t, a, z) => {
    if (t === 'mvhd') { const v = moov[a]; const ts = v === 1 ? moov.readUInt32BE(a + 20) : moov.readUInt32BE(a + 12); const d = v === 1 ? Number(moov.readBigUInt64BE(a + 24)) : moov.readUInt32BE(a + 16); if (ts) m.dur = d / ts; }
    else if (t === 'trak' || t === 'mdia' || t === 'minf' || t === 'stbl' || t === 'udta' || t === 'ilst') walkBox(a, z);
    else if (t === 'meta') walkBox(a + 4, z);
    else if (t === 'stsd') { const ent = moov.toString('latin1', a + 12, a + 16); if (ent === 'alac') m.codec = 'ALAC'; m.ch = moov.readUInt16BE(a + 8 + 8 + 16); m.bits = ent === 'alac' ? moov.readUInt16BE(a + 8 + 8 + 18) : 0; m.sr = moov.readUInt16BE(a + 8 + 8 + 24); }
    else if (MAP[t] || t === 'trkn' || t === 'disk' || t === 'covr' || t === 'gnre') kids(moov, a, z, (dt, da, dz) => {
      if (dt !== 'data') return; const kind = moov.readUInt32BE(da) & 0xffffff; const v = moov.subarray(da + 8, dz);
      if (t === 'covr') { if (v.length > 100 && !m.pic) m.pic = { type: 3, mime: kind === 14 ? 'image/png' : 'image/jpeg', data: v }; }
      else if (t === 'trkn' || t === 'disk') { if (v.length >= 4) m.tags[t === 'trkn' ? 'TRACKNUMBER' : 'DISCNUMBER'] = String(v.readUInt16BE(2)); }
      else if (MAP[t] && !(MAP[t] in m.tags)) m.tags[MAP[t]] = clean(v.toString('utf8'));
    });
  });
  walkBox(0, moov.length);
  if (m.dur) m.kbps = Math.round((size * 8) / m.dur / 1000);
  return m;
}
// ---------- WAV ----------
async function wavMeta(fh, size) {
  const b = await readAt(fh, 0, 4096); if (b.toString('latin1', 0, 4) !== 'RIFF' || b.toString('latin1', 8, 12) !== 'WAVE') return null;
  const m = { codec: 'WAV', tags: {} }; let o = 12, rate = 0;
  while (o + 8 <= b.length) {
    const id = b.toString('latin1', o, o + 4), len = b.readUInt32LE(o + 4);
    if (id === 'fmt ') { m.ch = b.readUInt16LE(o + 10); m.sr = b.readUInt32LE(o + 12); rate = b.readUInt32LE(o + 16); m.bits = b.readUInt16LE(o + 22); }
    if (id === 'data') { if (rate) m.dur = Math.min(len, size - o - 8) / rate; break; }
    o += 8 + len + (len & 1);
  }
  if (rate) m.kbps = Math.round((rate * 8) / 1000);
  return m;
}
async function readMeta(p, size) {
  const ext = extOf(p); const fh = await openR(p); size = fh.size;
  try {
    let m = null;
    if (ext === '.flac') m = await flacMeta(fh, size);
    else if (ext === '.mp3') m = await mp3Meta(fh, size);
    else if (ext === '.wav') m = await wavMeta(fh, size);
    else if (ext === '.ogg' || ext === '.oga' || ext === '.opus') m = await oggMeta(fh, size, ext === '.oga' ? '.ogg' : ext);
    else if (ext === '.m4a' || ext === '.m4b' || ext === '.mp4' || ext === '.aac') m = ext === '.aac' ? null : await mp4Meta(fh, size);
    return m || { codec: AUDIO[ext] || ext.slice(1).toUpperCase(), tags: {} };
  } finally { await fh.close().catch(() => {}); }
}

// ---------- CUE ----------
function parseCue(text) {
  const cue = { tags: {}, files: [] }; let file = null, tr = null;
  const val = (s) => { s = s.trim(); return s[0] === '"' ? s.slice(1, s.lastIndexOf('"') > 0 ? s.lastIndexOf('"') : undefined) : s; };
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim(); if (!line) continue;
    const sp = line.indexOf(' '); const cmd = (sp < 0 ? line : line.slice(0, sp)).toUpperCase(); const rest = sp < 0 ? '' : line.slice(sp + 1);
    if (cmd === 'FILE') { const q = rest.match(/^"(.*)"\s*(\w*)$/) || rest.match(/^(\S+)\s*(\w*)$/); file = { name: q ? q[1] : rest, kind: q ? String(q[2] || '').toUpperCase() : '', tracks: [] }; cue.files.push(file); tr = null; }
    else if (cmd === 'TRACK') { if (!file) continue; tr = { n: parseInt(rest, 10) || file.tracks.length + 1, type: String(rest.trim().split(/\s+/)[1] || 'AUDIO').toUpperCase(), tags: {}, start: null }; file.tracks.push(tr); }
    else if (cmd === 'INDEX' && tr) { const [no, t] = rest.trim().split(/\s+/); const mm = String(t || '').split(':').map(Number); if (mm.length === 3 && mm.every((x) => isFinite(x))) { const s = mm[0] * 60 + mm[1] + mm[2] / 75; if (+no === 1) tr.start = s; else if (+no === 0 && tr.start == null) tr.pre = s; } }
    else if (cmd === 'TITLE' || cmd === 'PERFORMER' || cmd === 'SONGWRITER' || cmd === 'ISRC') (tr ? tr.tags : cue.tags)[cmd] = val(rest);
    else if (cmd === 'REM') { const sp2 = rest.indexOf(' '); if (sp2 > 0) { const k = rest.slice(0, sp2).toUpperCase(); (tr ? tr.tags : cue.tags)[k] = val(rest.slice(sp2 + 1)); } }
    else if (cmd === 'CATALOG') cue.tags.CATALOG = rest.trim();
  }
  for (const f of cue.files) f.tracks = f.tracks.filter((t) => (t.start != null || t.pre != null) && t.type === 'AUDIO').map((t) => ({ ...t, start: t.start != null ? t.start : t.pre }));
  return cue;
}
// файл из CUE не всегда называется так же (в CUE «.wav», а на диске «.flac») — ищем похожий
function resolveCueFile(dir, name, siblings) {
  const want = path.join(dir, name.replace(/[\\/]/g, path.sep));
  const low = new Map(siblings.map((p) => [p.toLowerCase(), p]));
  if (low.has(want.toLowerCase())) return low.get(want.toLowerCase());
  const base = path.join(dir, path.basename(name, path.extname(name))).toLowerCase();
  for (const ext of Object.keys(AUDIO)) if (low.has(base + ext)) return low.get(base + ext);
  return null;
}

// обложка из папки, если в файлах её нет: cover/folder/front рядом с музыкой → любая картинка рядом (самая большая) →
// подпапки Scans/Covers/Artwork → папка выше (для CD1/CD2). «Задник», диск и вкладыш — в последнюю очередь.
const SUB = /^(scans?|covers?|artwork|art|images?|pics?|booklet|обложк\w*|сканы?|скан\w*)$/i;
const BACK = /(back|rear|tray|inlay|inside|interior|booklet|book|leaflet|spine|side|matrix|label|disc|disk|cd\s*\d|(^|[^a-z])cd([^a-z]|$)|obi|задн|оборот|вкладыш|буклет|диск|корешок)/;
const FRONT = /(front|перед|лицев)/;
function pickCover(d, imgDir) {
  const score = (x, extra, i) => { const b = path.basename(x.p).toLowerCase().replace(/\.[a-z]+$/, '');
    let r;
    if (FRONT.test(b)) r = 0;                                              // «front», «Cover (front)», «лицевая»
    else if (BACK.test(b)) r = 7;                                          // задник, вкладыш, диск — даже если в названии есть «cover»
    else if (/^(cover|folder|обложка)/.test(b) || /(^|[^a-z])cover([^a-z]|$)/.test(b)) r = 0;
    else if (/^(albumart|album|art)/.test(b)) r = 1;
    else r = 3 + Math.min(0.9, i * 0.05);                                  // безымянные сканы: «01», «02»… — первый обычно лицевая
    return r + extra; };
  const cands = []; const add = (list, extra) => [...list].sort((a, b) => a.p.localeCompare(b.p, 'ru', { numeric: true })).forEach((x, i) => cands.push([score(x, extra, i), x.p]));
  add(imgDir.get(d) || [], 0);
  for (const [dir, list] of imgDir) if (path.dirname(dir) === d && SUB.test(path.basename(dir))) add(list, 2);
  if (/^(cd|disc|disk|диск)\s*\d+$/i.test(path.basename(d))) add(imgDir.get(path.dirname(d)) || [], 1);
  cands.sort((a, b) => a[0] - b[0]);
  return cands.length ? { p: cands[0][1], r: cands[0][0] } : null;
}
// обложка альбома: из файла — если это лицевая (или «другая») картинка; задник из файла уступает лицевой из папки
function chooseCover(m, d, imgDir) {
  const f = pickCover(d, imgDir); const e = m.cov ? embRank(m.covType == null ? 0 : m.covType) : 99;
  if (m.cov && (!f || e <= f.r)) return m.cov;
  return f ? f.p : m.cov || '';
}

async function thumbOf(src, thumbs, keep) {
  try {
    const st = await fsp.stat(src); const old = thumbs[src];
    if (old && old.m === st.mtimeMs && old.s === st.size) { if (old.t === src) { keep[src] = old; return src; } try { await fsp.access(old.t); keep[src] = old; return old.t; } catch {} }
    if (!nativeImage) return src;
    await new Promise((r) => setImmediate(r));   // не держим главный процесс подряд — окно и звук не должны ждать
    const img = nativeImage.createFromPath(src); if (img.isEmpty()) return src;
    const { width, height } = img.getSize(); let t = src;
    if (width > 440 || height > 440 || st.size > 300 * 1024) {
      const r = width >= height ? img.resize({ width: Math.min(400, width), quality: 'good' }) : img.resize({ height: Math.min(400, height), quality: 'good' });
      t = path.join(covDir(), 't_' + sha(src + '|' + st.mtimeMs + '|' + st.size).slice(0, 20) + '.jpg');
      await fsp.mkdir(covDir(), { recursive: true }); await fsp.writeFile(t, r.toJPEG(86));
    }
    keep[src] = { m: st.mtimeMs, s: st.size, t }; return t;
  } catch { return src; }
}

// ---------- обход папок ----------
async function walk(root, out, depth = 0) {
  if (out.length >= MAX_FILES || depth > MAX_DEPTH) return;
  let st; try { st = await fsp.stat(root); } catch { return; }
  if (st.isFile()) { out.push({ p: root, m: st.mtimeMs, s: st.size }); return; }
  if (!st.isDirectory()) return;
  let ents; try { ents = await fsp.readdir(root, { withFileTypes: true }); } catch { return; }
  for (const e of ents) {
    if (e.name[0] === '.' || e.name === '$RECYCLE.BIN' || e.name === 'System Volume Information') continue;
    const p = path.join(root, e.name);
    if (e.isDirectory()) await walk(p, out, depth + 1);
    else if (e.isFile()) { const ext = path.extname(e.name).toLowerCase(); if (AUDIO[ext] || ext === '.cue' || IMG.test(e.name) || DISC.test(e.name)) { try { const s = await fsp.stat(p); out.push({ p, m: s.mtimeMs, s: s.size }); } catch {} } }
  }
}
async function savePic(pic) {
  const ext = imgExt(pic.data) || (/png/i.test(pic.mime) ? '.png' : '.jpg');
  const h = sha(pic.data).slice(0, 20); const f = path.join(covDir(), h + ext);
  try { await fsp.access(f); } catch { await fsp.mkdir(covDir(), { recursive: true }); await fsp.writeFile(f, pic.data); }
  return f;
}
const num = (s) => { const n = parseInt(String(s || '').split('/')[0], 10); return isFinite(n) ? n : 0; };
// имя папки для названия альбома: у корня образа — имя образа без «.iso»
const nice = (d) => { const b = path.basename(d); return b.endsWith(VSEP) ? b.slice(0, -VSEP.length).replace(/\.iso$/i, '') : b; };
const year = (s) => { const m = String(s || '').match(/\d{4}/); return m ? m[0] : ''; };
const fmtOf = (m) => ({ codec: m.codec, sr: m.sr || 0, bits: m.bits || 0, ch: m.ch || 0, kbps: m.kbps || 0, vbr: !!m.vbr });

async function scan() {
  if (scanning) { scanning.again = true; return; }
  scanning = { done: 0, total: 0, name: '' }; send('local:progress', scanning);
  try {
    do {
      scanning.again = false;
      const all = []; for (const r of lib.roots) await walk(r, all);
      stamps = new Map(all.map((x) => [x.p, { m: x.m, s: x.s }]));
      const hid = new Set(lib.hidden);
      // образы дисков: файлы внутри ISO и звук аудио-CD из BIN/IMG становятся «виртуальными» файлами
      const V = new Map(); const isoc = {}; const extra = []; const extraImg = []; const extraCue = [];
      for (const x of all) {
        if (!/\.iso$/i.test(x.p) || hid.has(x.p)) continue;
        const old = lib.isoc && lib.isoc[x.p]; let L = old && old.m === x.m && old.s === x.s ? old.items : null;
        if (!L) { scanning.name = path.basename(x.p); send('local:progress', { done: scanning.done, total: scanning.total, name: scanning.name }); try { L = (await isoList(x.p)).items; } catch (e) { L = []; log('своя музыка: образ', path.basename(x.p), e && e.message); } }
        isoc[x.p] = { m: x.m, s: x.s, items: L };
        for (const it of L) {
          const vp = x.p + VSEP + it.rel; const ext = path.extname(it.rel).toLowerCase();
          if (AUDIO[ext]) { V.set(vp, { src: x.p, off: it.off, size: it.size }); if (!hid.has(vp)) extra.push({ p: vp, m: x.m, s: it.size }); }
          else if (ext === '.cue' && it.size < 1024 * 1024) { V.set(vp, { src: x.p, off: it.off, size: it.size }); extraCue.push({ p: vp, m: x.m, s: it.size }); }
          else if (IMG.test(it.rel) && it.size < 20 * 1024 * 1024) extraImg.push({ iso: x.p, it, vd: path.dirname(vp), m: x.m });
        }
      }
      lib.isoc = isoc;
      vfs = V;   // уже нужно, чтобы прочитать CUE внутри образов
      const cues = all.filter((x) => path.extname(x.p).toLowerCase() === '.cue').concat(extraCue);
      const cueTxt = new Map();
      for (const c of cues) {
        try { const cue = parseCue(textAuto(await readAll(c.p))); cueTxt.set(c.p, cue); const dir = path.dirname(c.p);
          for (const f of cue.files) {
            if (!/\.(bin|img)$/i.test(f.name) || f.kind === 'MOTOROLA') continue;
            const want = path.join(dir, f.name.replace(/[\\/]/g, path.sep)).toLowerCase(); const b = all.find((y) => y.p.toLowerCase() === want); if (!b) continue;
            const vp = b.p + VSEP + 'audio-cd.wav'; f.resolved = vp;
            if (!V.has(vp)) { V.set(vp, { src: b.p, off: 0, size: b.s - (b.s % 4), wav: true }); if (!hid.has(vp)) extra.push({ p: vp, m: b.m, s: b.s }); }
          }
        } catch {}
      }
      vfs = V;
      const audio = all.filter((x) => AUDIO[path.extname(x.p).toLowerCase()] && !hid.has(x.p)).concat(extra);
      const imgs = all.filter((x) => IMG.test(path.basename(x.p)));
      // картинки из образов достаём в папку обложек один раз (обложку можно показать только из настоящего файла)
      for (const g of extraImg) {
        try { const f = path.join(covDir(), 'iso-' + fid(g.iso), String(g.it.off) + '-' + path.basename(g.it.rel).replace(/[^\w.\-а-яё ]+/gi, '_'));
          try { await fsp.access(f); } catch { const fh = await fsp.open(g.iso, 'r'); try { const b = await readAt(fh, g.it.off, g.it.size); await fsp.mkdir(path.dirname(f), { recursive: true }); await fsp.writeFile(f, b); } finally { await fh.close().catch(() => {}); } }
          imgs.push({ p: f, m: g.m, s: g.it.size, vd: g.vd }); } catch {}
      }
      const byDir = new Map(); for (const x of audio) { const d = path.dirname(x.p); if (!byDir.has(d)) byDir.set(d, []); byDir.get(d).push(x.p); }
      const imgDir = new Map(); for (const x of imgs) { const d = x.vd || path.dirname(x.p); if (!imgDir.has(d)) imgDir.set(d, []); imgDir.get(d).push(x); }
      scanning.total = audio.length; let lastSend = 0;
      const cache = {}; const meta = new Map();
      for (const x of audio) {
        const old = lib.cache[x.p]; let m = old && old.m === x.m && old.s === x.s && old.meta && old.meta.pv === PV ? old.meta : null;
        if (!m) { try { const r = await readMeta(x.p, x.s); m = { ...r, pv: PV, cov: r.pic ? await savePic(r.pic).catch(() => '') : '', covType: r.pic ? r.pic.type : null }; delete m.pic; } catch (e) { m = { codec: AUDIO[extOf(x.p)], tags: {}, err: String(e && e.message) }; } }
        if (vfs.has(x.p) && vfs.get(x.p).wav) m = { ...m, codec: 'CD' };
        cache[x.p] = { m: x.m, s: x.s, meta: m }; meta.set(x.p, m);
        scanning.done++; scanning.name = path.basename(path.dirname(x.p));
        if (Date.now() - lastSend > 400) { lastSend = Date.now(); send('local:progress', { done: scanning.done, total: scanning.total, name: scanning.name }); }
      }
      lib.cache = cache;
      // обложки и файлы
      const F = new Map(), C = new Map(); const covId = (p) => { if (!p) return ''; const k = fid(p); C.set(k, p); return 'pulsefile://c/' + k; };
      const out = []; const used = new Set();
      const mk = (p, m, t) => { const k = fid(p); F.set(k, p); return k; };
      // альбомы одним файлом: CUE рядом с файлом или CUE внутри FLAC
      const cueJobs = [];
      for (const c of cues) { const cue = cueTxt.get(c.p); if (cue) cueJobs.push({ cue, dir: path.dirname(c.p), src: c.p }); }
      for (const x of audio) { const m = meta.get(x.p); if (m && m.tags && m.tags.CUESHEET) { const cue = parseCue(m.tags.CUESHEET); if (cue.files.length) { cue.files.forEach((f) => { f.name = path.basename(x.p); }); cueJobs.push({ cue, dir: path.dirname(x.p), src: x.p, embedded: true }); } } }
      for (const j of cueJobs) {
        const sib = byDir.get(j.dir) || [];
        for (const f of j.cue.files) {
          const p = f.resolved || resolveCueFile(j.dir, f.name, sib); if (!p || used.has(p)) continue; const m = meta.get(p); if (!m || !f.tracks.length) continue;
          used.add(p); const k = mk(p); const ct = j.cue.tags; const ft = m.tags || {};
          const albumTitle = ct.TITLE || ft.ALBUM || nice(j.dir); const albumArtist = ct.PERFORMER || ft.ALBUMARTIST || ft.ARTIST || 'Неизвестный артист';
          const cov = covId(chooseCover(m, j.dir, imgDir));
          f.tracks.forEach((t, i) => {
            const nx = f.tracks[i + 1]; const s = t.start; const e = nx ? nx.start : 0; const dur = (e || m.dur || 0) - s;
            out.push({ id: 'loc:' + k + '-' + t.n, title: t.tags.TITLE || 'Трек ' + t.n, artist: t.tags.PERFORMER || albumArtist, albumArtist, albumTitle, dir: j.dir, n: t.n, disc: num(ct.DISCNUMBER) || 1,
              year: year(ct.DATE || ft.DATE), genre: ct.GENRE || ft.GENRE || '', dur: Math.max(0, dur), cover: cov, file: k, s, e, cue: true, fmt: fmtOf(m), size: lib.cache[p].s,
              extra: { label: ct.LABEL || ft.LABEL || ft.ORGANIZATION || '', catalog: ct.CATALOG || ct.CATALOGNUMBER || ft.CATALOGNUMBER || '', comment: ct.COMMENT || ft.COMMENT || '', cueName: j.embedded ? '' : path.basename(j.src), fileName: vfs.has(p) && vfs.get(p).wav ? path.basename(realOf(p)) : path.basename(String(p).split(VSEP).pop()) } });
          });
        }
      }
      for (const x of audio) {
        if (used.has(x.p)) continue; const m = meta.get(x.p) || { tags: {} }; const t = m.tags || {}; const k = mk(x.p); const d = path.dirname(x.p);
        const title = t.TITLE || path.basename(x.p, path.extname(x.p)).replace(/^\d{1,3}[\s.\-_]+/, '');
        const artist = t.ARTIST || t.ALBUMARTIST || 'Неизвестный артист';
        out.push({ id: 'loc:' + k, title, artist, albumArtist: t.ALBUMARTIST || t.ARTIST || artist, albumTitle: t.ALBUM || (/^(cd|disc|disk|диск)\s*\d+$/i.test(path.basename(d)) ? nice(path.dirname(d)) : nice(d)), dir: d, n: num(t.TRACKNUMBER), disc: num(t.DISCNUMBER) || 1,
          year: year(t.DATE || t.YEAR), genre: t.GENRE || '', dur: m.dur || 0, cover: covId(chooseCover(m, d, imgDir)), file: k, s: 0, e: 0, cue: false, fmt: fmtOf(m), size: x.s,
          extra: { label: t.LABEL || t.ORGANIZATION || '', catalog: t.CATALOGNUMBER || '', comment: t.COMMENT || '', fileName: path.basename(x.p.split(VSEP).pop()) } });
      }
      // маленькие копии обложек (400 точек) для списков и сеток: картинки из файлов бывают по 3000 точек и несколько
      // мегабайт — десятки таких на экране сильно тормозили «Мою музыку». Полная обложка — только в большом плеере.
      scanning.name = 'обложки'; const thumbs = lib.thumbs || {}; const done = new Map(); const keep = {};
      for (const t of out) {
        if (!t.cover) continue; const src = C.get(t.cover.slice('pulsefile://c/'.length)); if (!src) continue;
        if (!done.has(src)) { done.set(src, await thumbOf(src, thumbs, keep)); }
        const tp = done.get(src); t.coverBig = t.cover;
        if (tp && tp !== src) { const tid = fid(tp); C.set(tid, tp); t.cover = 'pulsefile://c/' + tid; }
      }
      lib.thumbs = keep;
      files = F; covers = C; tracks = out; save();
    } while (scanning.again);
  } catch (e) { log('своя музыка: ошибка разбора', e); }
  scanning = null; send('local:progress', null); send('local:changed', Date.now());
  watchRoots();
}

// ---------- новые файлы появляются сами ----------
const watchers = new Map(); let wT = null;
function watchRoots() {
  for (const [r, w] of watchers) if (!lib.roots.includes(r)) { try { w.close(); } catch {} watchers.delete(r); }
  for (const r of lib.roots) {
    if (watchers.has(r)) continue;
    try {
      const st = fs.statSync(r); if (!st.isDirectory()) continue;
      const w = fs.watch(r, { recursive: true }, (ev, name) => {
        const ext = path.extname(String(name || '')).toLowerCase(); if (name && !AUDIO[ext] && ext !== '.cue' && !DISC.test(String(name)) && !IMG.test(path.basename(String(name)))) return;
        // Windows присылает «change» и когда файл просто читают (в том числе сам плеер) — пересматриваем папку, только
        // если файл правда изменился (размер или дата) или появился / пропал
        if (ev === 'change' && name) {
          const fp = path.join(r, String(name)); const c = stamps.get(fp);
          fs.stat(fp, (e, st) => { if (e || !c || c.m !== st.mtimeMs || c.s !== st.size) { clearTimeout(wT); wT = setTimeout(scan, 4000); } });
          return;
        }
        clearTimeout(wT); wT = setTimeout(scan, 4000);
      });
      w.on('error', () => { try { w.close(); } catch {} watchers.delete(r); });
      watchers.set(r, w);
    } catch {}
  }
}

// ---------- отдача звука и обложек окну ----------
function headers(extra) { return { 'access-control-allow-origin': '*', 'cache-control': 'no-store', ...extra }; }
async function serve(req) {
  let u; try { u = new URL(req.url); } catch { return new Response(null, { status: 400 }); }
  const key = u.pathname.replace(/^\/+/, '').split('/')[0];
  if (u.hostname === 'c') {
    const p0 = covers.get(key); if (!p0) return new Response(null, { status: 404, headers: headers() });
    const p = p0;   // уменьшенные копии готовятся заранее при разборе папок (см. thumbOf)
    try { const b = await fsp.readFile(p); return new Response(b, { status: 200, headers: headers({ 'content-type': /\.png$/i.test(p) ? 'image/png' : /\.webp$/i.test(p) ? 'image/webp' : /\.gif$/i.test(p) ? 'image/gif' : /\.bmp$/i.test(p) ? 'image/bmp' : 'image/jpeg', 'cache-control': 'max-age=86400' }) }); }
    catch { return new Response(null, { status: 404, headers: headers() }); }
  }
  if (u.hostname !== 'a') return new Response(null, { status: 404, headers: headers() });
  const p = files.get(key); if (!p) return new Response(null, { status: 404, headers: headers() });
  let fh; try { fh = await openR(p); } catch { return new Response(null, { status: 404, headers: headers() }); }
  const st = { size: fh.size };
  const type = MIME[extOf(p)] || 'application/octet-stream';
  const rg = /bytes=(\d*)-(\d*)/.exec(req.headers.get('range') || '');
  if (!rg || rg[1] === '0') try { require('./perfwatch').kick('свой файл'); } catch {}
  let start = 0, end = st.size - 1, status = 200;
  if (rg) { status = 206; if (rg[1] === '' && rg[2]) { start = Math.max(0, st.size - +rg[2]); } else { start = +rg[1] || 0; if (rg[2]) end = Math.min(+rg[2], st.size - 1); } }
  if (start > end || start >= st.size) { fh.close().catch(() => {}); return new Response(null, { status: 416, headers: headers({ 'content-range': 'bytes */' + st.size }) }); }
  // Звук отдаём своим потоком: читаем файл кусками по 256 КБ ровно тогда, когда плеер просит следующий (а не
  // заранее весь хвост файла), и закрываем файл, как только плеер прервал запрос (перемотка, другой трек).
  // Раньше поток из Node мог «застревать» — звук пропадал на пару секунд и возвращался.
  let pos = start, closed = false;
  const close = () => { if (!closed) { closed = true; fh.close().catch(() => {}); } };
  const body = new ReadableStream({
    async pull(c) {
      try {
        const n = Math.min(256 * 1024, end + 1 - pos); if (n <= 0) { close(); c.close(); return; }
        const b = Buffer.allocUnsafe(n); const { bytesRead } = await fh.read(b, 0, n, pos);
        if (!bytesRead) { close(); c.close(); return; }
        pos += bytesRead; c.enqueue(new Uint8Array(b.buffer, b.byteOffset, bytesRead));
        if (pos > end) { close(); c.close(); }
      } catch (e) { close(); c.error(e); }
    },
    cancel() { close(); },
  }, { highWaterMark: 4 });
  return new Response(body, { status, headers: headers({ 'content-type': type, 'content-length': String(end - start + 1), 'accept-ranges': 'bytes', ...(status === 206 ? { 'content-range': `bytes ${start}-${end}/${st.size}` } : {}) }) });
}

// ---------- для окна ----------
function list() { return { roots: lib.roots.map((r) => ({ path: r, name: path.basename(r) || r, n: tracks.filter((t) => t.dir === r || t.dir.startsWith(r + path.sep) || files.get(t.file) === r).length })), tracks: tracks.map(({ dir, ...t }) => ({ ...t, folder: dir })), scanning: scanning ? { done: scanning.done, total: scanning.total, name: scanning.name } : null, hidden: lib.hidden.length }; }
function addRoots(paths) {
  let n = 0;
  for (const p0 of [].concat(paths || [])) {
    if (typeof p0 !== 'string' || !p0 || !path.isAbsolute(p0)) continue; const p = path.resolve(p0);
    try { fs.statSync(p); } catch { continue; }
    // уже внутри добавленной папки — не дублируем; добавили папку выше — вложенные убираем
    if (lib.roots.some((r) => p === r || p.startsWith(r + path.sep))) continue;
    lib.roots = lib.roots.filter((r) => !r.startsWith(p + path.sep)); lib.roots.push(p); n++;
  }
  if (n) { save(); scan(); }
  return n;
}
function setup(o) {
  log = (o && o.log) || log; const sec = o.sec; load();
  protocol.handle('pulsefile', (req) => serve(req).catch((e) => { log('своя музыка: отдача', e && e.message); return new Response(null, { status: 500 }); }));
  sec.handle('local:list', () => list());
  sec.handle('local:pick', async (e) => {
    const w = BrowserWindow.fromWebContents(e.sender);
    const r = await dialog.showOpenDialog(w, { title: 'Папка с музыкой', properties: ['openDirectory', 'multiSelections'] });
    return r.canceled ? 0 : addRoots(r.filePaths);
  });
  sec.handle('local:add', (_e, paths) => addRoots(Array.isArray(paths) ? paths.slice(0, 200) : []));
  sec.handle('local:remove', (_e, root) => { const before = lib.roots.length; lib.roots = lib.roots.filter((r) => r !== root); if (lib.roots.length !== before) { save(); scan(); } return true; });
  sec.handle('local:rescan', () => { scan(); return true; });
  // убрать из «Пульса» (файлы на диске не трогаем): сразу пропадают из списка, при следующих просмотрах папок не возвращаются
  sec.handle('local:hide', (_e, ids) => {
    const want = new Set([].concat(ids || []).map(String)); const ps = new Set();
    for (const t of tracks) if (want.has(t.id)) { const p = files.get(t.file); if (p) ps.add(p); }
    if (!ps.size) return 0;
    const keys = new Set([...ps].map((p) => fid(p))); lib.hidden = [...new Set([...lib.hidden, ...ps])];
    tracks = tracks.filter((t) => !keys.has(t.file)); save(); send('local:changed', Date.now()); return ps.size;
  });
  sec.handle('local:unhide', () => { if (!lib.hidden.length) return 0; const n = lib.hidden.length; lib.hidden = []; save(); scan(); return n; });
  sec.handle('local:reveal', (_e, id) => { const t = tracks.find((x) => x.id === id); const p = t && files.get(t.file); if (p) shell.showItemInFolder(realOf(p)); return !!p; });
  if (lib.roots.length) setTimeout(scan, 2500);   // после запуска — тихо проверяем, не добавилось ли что-то
}
module.exports = { setup };
