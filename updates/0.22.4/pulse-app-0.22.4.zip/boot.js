// Загрузчик «Пульса» для Mac.
//
// Программа на Mac подписана, и менять файлы внутри Pulse.app нельзя — macOS сочтёт её повреждённой.
// Поэтому обновления ставятся рядом, в папку пользователя: ~/Library/Application Support/Pulse/ota/<версия>/.
// Загрузчик при каждом запуске смотрит туда: если там версия новее встроенной и ей подходит этот движок
// (Electron), запускается она, иначе — встроенная.
//
// Защита от неудачного обновления: перед запуском версии из ota/ загрузчик отмечает попытку, а программа снимает
// отметку, как только показала окно. Две попытки подряд без окна — версия считается сломанной, и «Пульс»
// возвращается к встроенной (или предыдущей) версии.
'use strict';
const { app } = require('electron');
const fs = require('fs');
const path = require('path');

const BUNDLED = (() => { try { return require('./package.json').version; } catch { return '0.0.0'; } })();
function newer(a, b) {
  const pa = String(a).split(/[.-]/).map((x) => parseInt(x, 10) || 0), pb = String(b).split(/[.-]/).map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d > 0; }
  return false;
}
const OTA = path.join(app.getPath('userData'), 'ota');
const STATE = path.join(OTA, 'state.json');
const read = () => { try { return JSON.parse(fs.readFileSync(STATE, 'utf8')) || {}; } catch { return {}; } };
const write = (s) => { try { fs.mkdirSync(OTA, { recursive: true }); fs.writeFileSync(STATE, JSON.stringify(s)); } catch {} };

// подходит ли версия из ota/: новее встроенной, движок подходит, файлы на месте, не помечена сломанной
function usable(s, v) {
  if (!v || !/^[\d.]+$/.test(v) || !newer(v, BUNDLED) || (s.bad || []).includes(v)) return false;
  const dir = path.join(OTA, v);
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8'));
    if (pkg.version !== v) return false;
    if (pkg.minElectron && newer(pkg.minElectron, process.versions.electron)) return false;
    return fs.existsSync(path.join(dir, 'main.js')) && fs.existsSync(path.join(dir, 'dist', 'index.html'));
  } catch { return false; }
}

function pick() {
  const s = read();
  // встроенная версия уже не старее скачанных (поставили новую Pulse.app) — старые обновления не нужны
  if (s.current && !newer(s.current, BUNDLED)) { cleanup(s, ''); return null; }
  let v = s.current;
  if (v && (s.tries || 0) >= 2) {   // два запуска подряд без окна — эта версия сломана
    s.bad = [...new Set([...(s.bad || []), v])].slice(-10);
    v = usable(s, s.previous) ? s.previous : '';
    s.current = v; s.previous = ''; s.tries = 0;
  }
  if (!usable(s, v)) { if (s.current) { s.current = ''; s.tries = 0; write(s); } return null; }
  s.tries = (s.tries || 0) + 1; write(s);
  return v;
}
// удалить папки версий, кроме нужных
function cleanup(s, keep) {
  try { for (const d of fs.readdirSync(OTA)) if (/^[\d.]+$/.test(d) && d !== keep && !(keep && d === s.previous)) fs.rmSync(path.join(OTA, d), { recursive: true, force: true }); } catch {}
  if (!keep) { s.current = ''; s.previous = ''; s.tries = 0; write(s); }
}

const v = pick();
global.__pulseBoot = {
  bundled: BUNDLED, version: v || BUNDLED, ota: OTA, fromOta: !!v,
  // программа показала окно — версия рабочая
  ok() { const s = read(); if (s.tries) { s.tries = 0; write(s); } },
};
if (v) {
  app.getVersion = () => v;
  try { require(path.join(OTA, v, 'main.js')); }
  catch (e) {
    // версия из ota/ не запустилась сразу — помечаем и запускаем предыдущую (или встроенную)
    const s = read(); s.bad = [...new Set([...(s.bad || []), v])].slice(-10); s.current = usable(s, s.previous) ? s.previous : ''; s.previous = ''; s.tries = 0; write(s);
    try { fs.mkdirSync(path.join(app.getPath('userData'), 'logs'), { recursive: true }); fs.appendFileSync(path.join(app.getPath('userData'), 'logs', 'pulse.log'), new Date().toISOString() + ' загрузчик: версия ' + v + ' не запустилась: ' + (e && e.stack || e) + '\n'); } catch {}
    app.relaunch(); app.exit(0);
  }
} else {
  require('./main.js');
}
